<?php
class PHP_Error_Job
{
	public function perform()
	{
		callToUndefinedFunction();
	}
}