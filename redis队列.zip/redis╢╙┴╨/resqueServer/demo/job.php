<?php

require __DIR__ . '/CommonConst.php';
require __DIR__ . '/Db/DB.php';
require __DIR__ . '/JPush/JpushTags.class.php';
require dirname(__DIR__).'/lib/Resque/Job/Status.php';

class PHP_Job {

    private $pdo;

    public function __construct() {
        $this->pdo = DB::getInstance('mysql:host=localhost;port=3306;dbname=Prostage;', 'prostage', 'prostage');
    }

    /**
     * perform之前
     */
    public function setUp() {
        
    }

    /**
     * job
     */
    public function perform() {
        try {
            $needInfo = $this->pdo->select(array('ml_need'), array('*'), array('where' => array('id=' . $this->args['n_id'])));
            if ($needInfo && $needInfo[0]['status'] == 1) { //需求状态正常
                $args = $this->getJpushData($needInfo); //主体数据
                $jpush = new JpushTags();
                $tags = $this->getNeedWtype($this->args['n_id']); //工种标签, 名称为id
                switch ($needInfo[0]['type']) { //类型标签
                    case 1: //个人
                        $type = 'A';
                        break;
                    case 2: //团队
                        $type = 'B';
                        break;
                    case 3: //公司
                        $type = 'C';
                        break;
                }
                $result = $jpush->sendJpushMsg($tags, $type, '有新订单啦，快去接单吧', $args);
                print_r($result);
            } else {
                echo 'Need Info Not Found';
            }
        } catch (Exception $ex) {
            echo 'DB ERROR';
        }
    }

    /**
     * perform之后
     */
    public function tearDown() {
        
    }
    
    public function fuckJob() {
        $status = new Resque_Job_Status($this->job->payload['id']);
        $this->saveJobLogStatus($this->job->payload['id'], $status->get());
    }

    /**
     * 出列时获取推送参数
     */
    public function getJpushData($needInfo) {
        //公司
        $companyParams['where'][] = 'id = ' . $needInfo[0]['com_id'];
        $companyInfo = $this->pdo->select(array('ml_company'), array('name'), $companyParams);
        //地址
        $inStr = trim("{$needInfo[0]['area_l1']},{$needInfo[0]['area_l2']},{$needInfo[0]['area_l3']}", ",");
        $areaParams['where'][] = "area_id in ({$inStr})";
        $areaParams['order'] = 'level asc';
        $areaArr = $this->pdo->select(array('ml_area'), array('area_name'), $areaParams);
        $address = $areaArr[0]['area_name'] . $areaArr[1]['area_name'] . $areaArr[2]['area_name'] . $needInfo[0]['address'];
        //图片  http://192.168.1.29/Prostage
        $needImgParams['where'][] = 'need_id = ' . $needInfo[0]['id'];
        $needImgArr = $this->pdo->select(array('ml_need_img'), array('url'), $needImgParams);
        if ($needImgArr) {
            $img = CommonConst::IMG_BASE_URL . $needImgArr[0]['url'];
        } else {
            $img = CommonConst::IMG_BASE_URL . '/Public/img/need_img1.png';
        }
        //合并数据 
        $args = array(
            'code' => 200,
            'msg' => '成功',
            'data' => array(
                'data1' => $needInfo[0]['title'] . ',' . '地址' . $address,
                'data2' => array(
                    'id' => $needInfo[0]['id'],
                    'comid' => $needInfo[0]['com_id'],
                    'company' => $companyInfo[0]['name'] ?: '',
                    'title' => $needInfo[0]['title'],
                    'img' => $img,
                    'ctime' => substr($needInfo[0]['ctime'], 0, -3),
                    'address' => $address
                )
            )
        );
        return $args;
    }

    /**
     * 获取需求所需工种
     * @param type $needId 需求的id
     */
    public function getNeedWtype($needId) {
        //所需工种
        $sql = "select nw.w_id from ml_need_wtype nw inner join ml_work_type w on w.id = nw.w_id and nw.need_id = " . $needId . " and w.status = 1";
        $needWtype = $this->pdo->execute($sql);
        $needWtypeRes = array();
        $needWtypeArr = array();
        if ($needWtype) {
            while ($row = $needWtype->fetch(PDO::FETCH_ASSOC)) {
                $needWtypeRes[] = $row;
            }
        }
        foreach ($needWtypeRes as $v) {
            $needWtypeArr[] = $v['w_id'];
        }
        return $needWtypeArr;
    }

    /**
     * 数据库操作
     * @param type $jobid
     */
    private function saveJobLogStatus($jobId, $status) {
        try {
            if ($this->pdo->execute('UPDATE `ml_job_log` set `status`=' . $status . ' WHERE `job_id`="' . $jobId . '"')) {
                echo 'success saveStatus';
            } else {
                echo 'error saveStatus';
            }
        } catch (Exception $ex) {
            echo 'DB ERROR';
        }
    }

}
