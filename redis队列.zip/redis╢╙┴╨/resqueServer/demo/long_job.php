<?php
class Long_PHP_Job
{
	public function perform()
	{
		sleep(600);
	}
}