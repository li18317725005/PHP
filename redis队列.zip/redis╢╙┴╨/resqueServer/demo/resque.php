<?php

date_default_timezone_set('GMT');
require 'job.php';

require '../bin/resque';
