<?php

require_once __DIR__.'/JPushException.class.php';

class APIConnectionException extends JPushException {

    function __toString() {
        return "\n" . __CLASS__ . " -- {$this->message} \n";
    }
}
