<?php
/*
 * 公共常量类
 */
class CommonConst {
    /**
     * 极光推送常量
     */
    const DEV_KEY = '7d14ae9a2343bc566499f585'; //php调用API使用
    const DEV_SECRET = '429dfcf294debd423ef54bfd'; //php调用API使用
    const APP_KEY = '9d271d22f1c45345650c6224';
    const MASTER_SECRET = 'afc9481319f31bdac8867680';
    
    
    /**
     * 文件路径常量
     */
    const IMG_BASE_URL = 'http://192.168.1.29/Prostage';
}

