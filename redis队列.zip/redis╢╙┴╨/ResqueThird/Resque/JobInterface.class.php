<?php
namespace OaLibs\Third\Resque\Resque;

interface Resque_JobInterface
{
	/**
	 * @return bool
	 */
	public function perform();
}
