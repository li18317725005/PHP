<?php
namespace OaLibs\Third\SendSms;

ini_set("display_errors", "on");

require_once __DIR__ . '/api_sdk/vendor/autoload.php';

use Aliyun\Core\Config;
use Aliyun\Core\Profile\DefaultProfile;
use Aliyun\Core\DefaultAcsClient;
use Aliyun\Api\Sms\Request\V20170525\SendSmsRequest;
use Aliyun\Api\Sms\Request\V20170525\QuerySendDetailsRequest;

// 加载区域结点配置
Config::load();

/**
 * 短信接口设置/配置
 *
 * @author 李海江 <18317725005@126.com>
 */
class Setting
{
    /**
     * 构造器
     *
     * @param string $accessKeyId 必填，AccessKeyId
     * @param string $accessKeySecret 必填，AccessKeySecret
     */
    public function __construct($accessKeyId, $accessKeySecret) {
        // 短信API产品名
        $product = "Dysmsapi";
        // 短信API产品域名
        $domain = "dysmsapi.aliyuncs.com";
        // 暂时不支持多Region
        $region = "cn-hangzhou";
        // 服务结点
        $endPointName = "cn-hangzhou";
        // 初始化用户Profile实例
        $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
        // 增加服务结点
        DefaultProfile::addEndpoint($endPointName, $region, $product, $domain);
        // 初始化AcsClient用于发起请求
        $this->acsClient = new DefaultAcsClient($profile);
    }

    /**
     * 发送短信范例
     *
     * @param string $signName
     * 必填, 短信签名，应严格"签名名称"填写，参考：<https://dysms.console.aliyun.com/dysms.htm#/sign>
     * 
     * @param string $templateCode
     * 必填, 短信模板Code，应严格按"模板CODE"填写, 参考：<https://dysms.console.aliyun.com/dysms.htm#/template>
     
     * @param string $phoneNumbers 必填, 短信接收号码 
     * @param array|null $templateParam 
     * 选填, 假如模板中存在变量需要替换则为必填项 ( Array("code"=>"123456", "product"=>"阿里通信"))
     * 
     * @param string|null $outId [optional] 选填, 发送短信流水号 (e.g. 1234)
     * @return stdClass
     */
    public function sendSms($signName, $templateCode, $phoneNumbers, $templateParam = null, $outId = null) {
        // 初始化SendSmsRequest实例用于设置发送短信的参数
        $request = new SendSmsRequest();
        // 必填，设置雉短信接收号码
        $request->setPhoneNumbers($phoneNumbers);
        // 必填，设置签名名称
        $request->setSignName($signName);
        // 必填，设置模板CODE
        $request->setTemplateCode($templateCode);
        // 可选，设置模板参数
        if($templateParam) {
            $request->setTemplateParam(json_encode($templateParam));
        }
        // 可选，设置流水号
        if($outId) {
            $request->setOutId($outId);
        }
        // 发起访问请求
        $acsResponse = $this->acsClient->getAcsResponse($request);
        // 打印请求结果
        return $acsResponse;

    }

    /**
     * 查询短信发送情况范例
     *
     * @param string $phoneNumbers 必填, 短信接收号码 (e.g. 12345678901)
     * @param string $sendDate 必填，短信发送日期，格式Ymd，支持近30天记录查询 (e.g. 20170710)
     * @param int $pageSize 必填，分页大小
     * @param int $currentPage 必填，当前页码
     * @param string $bizId 选填，短信发送流水号 (e.g. abc123)
     * @return stdClass
     */
    public function queryDetails($phoneNumbers, $sendDate, $pageSize = 10, $currentPage = 1, $bizId=null) {
        // 初始化QuerySendDetailsRequest实例用于设置短信查询的参数
        $request = new QuerySendDetailsRequest();
        // 必填，短信接收号码
        $request->setPhoneNumber($phoneNumbers);
        // 选填，短信发送流水号
        $request->setBizId($bizId);
        // 必填，短信发送日期，支持近30天记录查询，格式Ymd
        $request->setSendDate($sendDate);
        // 必填，分页大小
        $request->setPageSize($pageSize);
        // 必填，当前页码
        $request->setCurrentPage($currentPage);
        // 发起访问请求
        $acsResponse = $this->acsClient->getAcsResponse($request);
        // 打印请求结果
        return $acsResponse;
    }
    
    /**
     * 根据错误码获取错误提示
     * @param type $Code 错误码
     * @return string 错误信息
     */
    public function getSmsError($Code) {
        switch ($Code) {
            case 'isp.RAM_PERMISSION_DENY' :
                return 'RAM权限DENY';
            case 'isv.OUT_OF_SERVICE' :
                return '业务停机';
            case 'isv.PRODUCT_UN_SUBSCRIPT' :
                return '未开通云通信产品的阿里云客户';
            case 'isv.PRODUCT_UNSUBSCRIBE' :
                return '产品未开通';
            case 'isv.ACCOUNT_NOT_EXISTS' :
                return '账户不存在';
            case 'isv.ACCOUNT_ABNORMAL' :
                return '账户异常';
            case 'isv.SMS_TEMPLATE_ILLEGAL' :
                return '短信模板不合法';
            case 'isv.SMS_SIGNATURE_ILLEGAL' :
                return '短信签名不合法';
            case 'isv.INVALID_PARAMETERS' :
                return '参数异常';
            case 'isp.SYSTEM_ERROR' :
                return '系统错误';
            case 'isv.MOBILE_NUMBER_ILLEGAL' :
                return '非法手机号';
            case 'isv.MOBILE_COUNT_OVER_LIMIT' :
                return '手机号码数量超过限制';
            case 'isv.TEMPLATE_MISSING_PARAMETERS' :
                return '模板缺少变量';
            case 'isv.BUSINESS_LIMIT_CONTROL' :
                return '业务限流';
            case 'isv.INVALID_JSON_PARAM' :
                return 'JSON参数不合法，只接受字符串值';
            case 'isv.BLACK_KEY_CONTROL_LIMIT' :
                return '黑名单管控';
            case 'isv.PARAM_LENGTH_LIMIT' :
                return '参数超出长度限制';
            case 'isv.PARAM_NOT_SUPPORT_URL' :
                return '不支持URL';
            case 'isv.AMOUNT_NOT_ENOUGH' :
                return  '账户余额不足';
            default :
                return  '发送失败';
        } 
    }
}
