<?php
/**
 * 发送验证码入口
 * 
 * @author 李海江 <18317725005@126.com>
 */
namespace OaLibs\Third\SendSms;

use OaLibs\Third\SendSms\Setting;
use OaLibs\SysConst\SysConst;

class Send {
    /**
     * 发送短信验证码
     * @param str $phone 接受短信的手机号
     * @setInc 是否更新phpsms表的num字段 +1
     */
    public function index($phone, $setInc = false) {
        //发送验证码
        $code = rand(100000, 999999); //随机生成6位验证码
        $smsObj = new Setting(SysConst::ACCESS_KEY_ID, SysConst::ACCESS_KEY_SECRET);
        $response = $smsObj->sendSms(
            "工程E站", // 短信签名
            "SMS_101615009", // 短信模板编号
            $phone,    // 短信接收者
            Array(  // 短信模板中字段的值
                "code"=>$code,
            )
        );
        //是否发送成功
        if ($response->Code == 'OK') {
            $smsInfo = array('code' => $code, 'sendTime' => time());
            S($phone, $smsInfo, 300);
            if ($setInc) {
                //接收短信验证码次数加1
                $phoneSmsSvc = new \OaLibs\Service\PhoneSms();
                $phoneSmsSvc->setNumIncByPhone($phone);
            }
            return array('code' => 200, 'msg' => '发送成功', 'data' => array('success' => 1));
        } else {
            $errorMsg = $smsObj->getSmsError($response->Code); //根据错误码获取错误信息
            return array('code' => -60, 'msg' => $errorMsg);
        }
    }
}


