<?php
/**
 * 快递鸟(http://www.kdniao.com/api-track)
 * 优点:
 * 1. 半年免费
 * 
 * 缺点:
 * 1. 要先根据运单号获取快递公司, 再根据运单号和快递公司获取物流信息
 */
namespace Home\Controller;

use Think\Controller;

class DemoOneController extends Controller
{
	public function index(){
		$LogisticCode = '3941142336469';  //物流运单号
		$EBusinessID = '1278422'; //商户ID
		$AppKey = '55774a19-0fdc-4dfb-b95c-884d336e38ed'; //密钥
		$ShipperCode = $this->getShipperCode($LogisticCode, $EBusinessID, $AppKey); //获取物流公司的编码
		$ShipperInfo = $this->getShipperInfo($ShipperCode, $LogisticCode, $EBusinessID, $AppKey);//获取物流信息
		$this->assign('ShipperInfo', $ShipperInfo['Traces']);
		$this->display();
	}

	/**
	 * 根据订单号获取快递公司编码
	 * @param  LogisticCode 物流运单号
	 * @param  EBusinessID  商户ID
	 * @param  AppKey       密钥
	 * @return ShipperCode  物流公司编码
	 */
	function getShipperCode($LogisticCode, $EBusinessID, $AppKey){
		$requestData = "{'LogisticCode':'".$LogisticCode."'}";
		$datas = array(
	        'EBusinessID' => $EBusinessID,
	        'RequestType' => '2002',
	        'RequestData' => urlencode($requestData) ,
	        'DataType' => '2',
	    );
	    $datas['DataSign'] = $this->getSign($requestData, $AppKey); //生成签名
	    $url = 'http://api.kdniao.cc/Ebusiness/EbusinessOrderHandle.aspx'; //请求接口地址
		$result = $this->sendPost($url, $datas);	
		//获取物流公司的编码
		$result = json_decode($result, true);
		$ShipperCode = $result['Shippers'][0]['ShipperCode'];
		return $ShipperCode;
	}
	

	/**
	 * 获取物流信息
	 * @param  ShipperCode  物流公司编码
	 * @param  LogisticCode 物流运单号
	 * @param  EBusinessID  商户ID
	 * @param  AppKey       密钥
	 * @return result       物流信息
	 */
	function getShipperInfo($ShipperCode, $LogisticCode, $EBusinessID, $AppKey){
		$requestData= "{'OrderCode':'','ShipperCode':'".$ShipperCode."','LogisticCode':'".$LogisticCode."'}";
		$datas = array(
	        'EBusinessID' => $EBusinessID,
	        'RequestType' => '1002',
	        'RequestData' => urlencode($requestData) ,
	        'DataType' => '2',
	    );
	    $datas['DataSign'] = $this->getSign($requestData, $AppKey); //生成签名
	  	$url = "http://api.kdniao.cc/Ebusiness/EbusinessOrderHandle.aspx"; //请求接口地址
		$result = $this->sendPost($url, $datas);
		$result = json_decode($result, true);
		return $result;
	}


	/**
	 * Sign签名生成
	 * @param data 内容   
	 * @param appkey Appkey
	 * @return DataSign签名
	 */
	function getSign($data, $appkey) {
	    return urlencode(base64_encode(md5($data.$appkey)));
	}																		


	/**
	 *  post提交数据 
	 * @param  string $url 请求Url
	 * @param  array $datas 提交的数据 
	 * @return url响应返回的html
	 */
	function sendPost($url, $datas) {
	    $temps = array();	
	    foreach ($datas as $key => $value) {
	        $temps[] = sprintf('%s=%s', $key, $value);		
	    }	
	    $post_data = implode('&', $temps);
	    $url_info = parse_url($url);
		if(empty($url_info['port']))
		{
			$url_info['port']=80;	
		}
	    $httpheader = "POST " . $url_info['path'] . " HTTP/1.0\r\n";
	    $httpheader.= "Host:" . $url_info['host'] . "\r\n";
	    $httpheader.= "Content-Type:application/x-www-form-urlencoded\r\n";
	    $httpheader.= "Content-Length:" . strlen($post_data) . "\r\n";
	    $httpheader.= "Connection:close\r\n\r\n";
	    $httpheader.= $post_data;
	    $fd = fsockopen($url_info['host'], $url_info['port']);
	    fwrite($fd, $httpheader);
	    $gets = "";
		$headerFlag = true;
		while (!feof($fd)) {
			if (($header = @fgets($fd)) && ($header == "\r\n" || $header == "\n")) {
				break;
			}
		}
	    while (!feof($fd)) {
			$gets.= fread($fd, 128);
	    }
	    fclose($fd);  
	    
	    return $gets;
	}


}