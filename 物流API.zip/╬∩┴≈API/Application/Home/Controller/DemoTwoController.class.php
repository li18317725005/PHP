<?php
/**
 * 阿里云市场-->全国快递查询(https://market.aliyun.com/products/57126001/cmapi011120.html#sku=yuncode512000008)
 * 优点: 
 * 1. 能自动识别快递公司
 * 缺点:
 * 1. 查询速度相对慢一些
 * 2. 收取费用0.001/200次,940元／200000次, 4500元／1000000次
 */
namespace Home\Controller;

use Think\Controller;

class DemoTwoController extends Controller
{
	/*显示物流信息*/
	public function index(){
	    $appcode = "5f0c594d3780407a9d5ceaf53c553d22"; //购买接口后给的密钥
	    $headers = array();
	    array_push($headers, "Authorization:APPCODE " . $appcode);
	    //获取快递信息
	    $number = '884267729326357744'; //物流运单号
	    $ShipperInfo = $this->getShipperInfo($headers, $number);
	    $this->assign('ShipperInfo', $ShipperInfo);
		$this->display();
	}


	/**
	 * 获取所有快递公司(这里用不上)
	 * @param  str $headers
	 */
	public function getShipperCode($headers){
		$host = "http://jisukdcx.market.alicloudapi.com"; //接口网址
		$path = "/express/type"; //接口路径
	    $url = $host . $path;    //接口地址
	    $result = $this->curl($url, $headers, $host); //获取接口返回结果 
	    $jsonarr = json_decode($result, true);
		return $jsonarr;
	}


	/**
	 * 获取快递信息
	 * @param  str $headers 
	 * @param  str $number 物流运单号
	 * @param  str $type   物流公司编码
	 */
	public function getShipperInfo($headers, $number, $type='auto'){
		$host = "http://jisukdcx.market.alicloudapi.com"; //接口网址
		$path = "/express/query"; //接口路径
	    $url = $host . $path . "?number=" . $number . "&type=" . $type; //接口地址
	    $result = $this->curl($url, $headers, $host);
	    $jsonarr = json_decode($result,true);
	    return $jsonarr['result'];
	}


	/**
	 * curl请求接口
	 */
	public function curl($url, $headers, $host){
		$curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    if (1 == strpos("$".$host, "https://"))
	    {
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	    }
	    $result = curl_exec($curl);
	    return $result;
	}

}


/*接口返回信息:
{
    "status": "0",
    "msg": "ok",
    "result": {
        "list": [
            {
                "time": "2015-10-20 10:24:04",
                "status": "顺丰速运 已收取快件"
            },
            {
                "time": "2015-10-20 11:49:26",
                "status": "快件离开【广州龙怡服务点】,正发往 【广州番禺集散中心】"
            }
            {
                "time": "2015-10-21 09:22:10",
                "status": "已签收,感谢使用顺丰,期待再次为您服务"
            },
            {
                "time": "2015-10-21 09:22:10",
                "status": "在官网\"运单资料&签收图\",可查看签收人信息"
            }
        ],
        "issign": "1" //1已签收, 0未签收
    }
}*/