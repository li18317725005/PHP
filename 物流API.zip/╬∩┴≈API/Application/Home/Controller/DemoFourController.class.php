<?php
/**
 * 阿里云市场-->快递查询API(https://market.aliyun.com/products/57126001/cmapi013624.html?spm=5176.730005.0.0.MV9QEk#sku=yuncode762400001)
 * 优点:
 * 1. 能自动识别快递号
 * 2. 能控制显示的信息量和信息排序
 * 缺点:
 * 1.收费2元／100次, 999元／100000次
 */
namespace Home\Controller;

use Think\Controller;

class DemoFourController extends Controller
{
	/*显示物流信息*/
	public function index(){
		$host = "http://aliapi.kuaidi.com"; //接口网址
	    $path = "/kuaidiinfo"; //接口路径
	    $appcode = "5f0c594d3780407a9d5ceaf53c553d22"; //密钥
	    $headers = array(); //请求参数Headers
	    array_push($headers, "Authorization:APPCODE " . $appcode);
	    //请求参数: nu订单号; com物流公司简码,省略则自动识别; muti返回结果数量; order排序
	    $querys = "nu=884267729326357744&muti=0&order=desc"; 
	    $bodys = ""; //请求参数Body
	    $url = $host . $path . "?" . $querys;
	    //获取物流信息
	    $result = $this->curl($url, $headers, $host);
	    $this->assign('result', $result);
		$this->display();
	}


	/*curl*/
	public function curl($url, $headers, $host){
		$curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    if (1 == strpos("$".$host, "https://"))
	    {
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	    }
	    $result = curl_exec($curl);
	    $result = json_decode($result, true);
	    return $result;
	}
}


/*接口返回信息:
{
  "success": true,
  "reason": "",
  "data": [
    {
      "time": "2016-04-26 00:21:26",
      "context": "到潍坊市【潍坊转运中心】"
    },
    {
      "time": "2016-04-25 18:16:34",
      "context": "威海市【威海集散仓】，正发往【潍坊转运中心】"
    },
    {
      "time": "2016-04-25 18:15:42",
      "context": "到威海市【威海集散仓】"
    },
    {
      "time": "2016-04-25 15:16:00",
      "context": "威海市【荣成】，正发往【威海集散仓】"
    },
    {
      "time": "2016-04-25 15:15:27",
      "context": "威海市【荣成】，【林波/13863000310】已揽收"
    }
  ],
  "status": 3,
  "exname": "huitongkuaidi",
  "ico": "http://www.kuaidi.com/data/upload/201407/htky_logo.gif",
  "phone": "400-956-5656",
  "url": "http://www.800bestex.com",
  "nu": "70186506140478",
  "company": "百世汇通"
}*/