<?php
/**
 * 阿里云市场-->全国快递查询(https://market.aliyun.com/products/57126001/cmapi010996.html?spm=5176.730005.0.0.MV9QEk#sku=yuncode499600008)
 * 优点: 
 * 1. 自动识别快递公司, 只需订单号就能查出快递公司名称和物流信息
 * 2. 查询速度快
 * 
 * 缺点: 
 * 1. 收取费用0.01元/100次, 999元／310000次, 2999元／1000000次
 */
namespace Home\Controller;

use Think\Controller;

class DemoThreeController extends Controller
{
	/*显示物流信息*/
	public function index(){
		$host = "http://ali-deliver.showapi.com"; //接口网址
	    $path = "/showapi_expInfo"; //接口路径
	    $appcode = "5f0c594d3780407a9d5ceaf53c553d22"; //秘钥
	    $headers = array(); //	请求参数Headers
	    array_push($headers, "Authorization:APPCODE " . $appcode);
	    $querys = "com=auto&nu=884267729326357744"; //查询参数,com快递公司编码(如果为auto可自动识别), nu物流运单号
	    $bodys = ""; //请求参数Body
	    $url = $host . $path . "?" . $querys; //接口全地址
	    //获取快递信息
	    $result = $this->curl($url, $headers, $host);
	    $this->assign('result', $result);
	    $this->display();
	}

	/*curl*/
	public function curl($url, $headers, $host){
		$curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    if (1 == strpos("$".$host, "https://"))
	    {
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	    }
	    $result = curl_exec($curl);
	    $result = json_decode($result, true);
	    return $result;
	}

}

/*接口返回信息:
{
	"showapi_res_code": 0,//showapi平台返回码,0为成功,其他为失败
	"showapi_res_error": "",//showapi平台返回的错误信息
	"showapi_res_body": {
		"mailNo": "968018776110",//快递单号
		"update": 1466926312666,//数据最后查询的时间
		"updateStr": "2016-06-26 15:31:52",//数据最后更新的时间
		"ret_code": 0,//接口调用是否成功,0为成功,其他为失败
		"flag": true,//物流信息是否获取成功
		"status": 4,-1 待查询 0 查询异常 1 暂无记录 2 在途中 3 派送中 4 已签收 5 用户拒签 6 疑难件 7 无效单
 8 超时单 9 签收失败 10 退回
		"tel": "400-889-5543",//快递公司电话
		"expSpellName": "shentong",//快递字母简称
		"data": [//具体快递路径信息
			{
				"time": "2016-06-26 12:26",
				"context": "已签收,签收人是:【本人】"
			},
			{
				"time": "2016-06-25 15:31",
				"context": "【陕西陇县公司】的派件员【西城业务员】正在派件"
			},
			{
				"time": "2016-06-25 14:11",
				"context": "快件已到达【陕西陇县公司】"
			},
			{
				"time": "2016-06-25 09:08",
				"context": "由【陕西宝鸡公司】发往【陕西陇县公司】"
			},
			{
				"time": "2016-06-24 14:08",
				"context": "由【陕西西安中转部】发往【陕西宝鸡公司】"
			},
			{
				"time": "2016-06-22 13:23",
				"context": "由【山东临沂公司】发往【陕西西安中转部】"
			},
			{
				"time": "2016-06-21 23:02",
				"context": "【江苏常熟公司】正在进行【装袋】扫描"
			},
			{
				"time": "2016-06-21 23:02",
				"context": "由【江苏常熟公司】发往【江苏江阴航空部】"
			},
			{
				"time": "2016-06-21 18:30",
				"context": "【江苏常熟公司】的收件员【严继东】已收件"
			},
			{
				"time": "2016-06-21 16:41",
				"context": "【江苏常熟公司】的收件员【凌明】已收件"
			}
		],
		"expTextName": "申通快递"//快递公司名
	}
}*/