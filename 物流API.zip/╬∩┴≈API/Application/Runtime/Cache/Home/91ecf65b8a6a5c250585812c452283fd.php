<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>阿里云快递查询3</title>
</head>
<body>
	<p>物流详情:</p>
	<?php if(is_array($result["data"])): foreach($result["data"] as $key=>$v): ?><p><span><?php echo ($v["time"]); ?> : </span>&nbsp;&nbsp;<span><?php echo ($v["context"]); ?></span></p><?php endforeach; endif; ?>
</body>
</html>