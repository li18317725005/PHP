<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>快递鸟物流查询</title>
</head>
<body>
	<p>物流详情:</p>
	<?php if(is_array($ShipperInfo)): foreach($ShipperInfo as $key=>$v): ?><p><span><?php echo ($v["AcceptTime"]); ?> : </span>&nbsp;&nbsp;<span><?php echo ($v["AcceptStation"]); ?></span></p><?php endforeach; endif; ?>
</body>
</html>