<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>阿里云物流信息查询2</title>
</head>
<body>
	<p>物流详情: </p>
	<?php if(is_array($result["showapi_res_body"]["data"])): foreach($result["showapi_res_body"]["data"] as $key=>$v): ?><p><span><?php echo ($v["time"]); ?> : </span>&nbsp;&nbsp;<span><?php echo ($v["context"]); ?></span></p><?php endforeach; endif; ?>
</body>
</html>