<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>demo首页</title>
</head>
<body>
	<a href="/Demo/index.php/Home/DemoOne/index"><input type="button" value="例一"></a><br/><br/>
	<a href="/Demo/index.php/Home/DemoTwo/index"><input type="button" value="例二"></a><br/><br/>
	<a href="/Demo/index.php/Home/DemoThree/index"><input type="button" value="例三"></a><br/><br/>
	<a href="/Demo/index.php/Home/DemoFour/index"><input type="button" value="例四"></a><br/><br/>
</body>
</html>