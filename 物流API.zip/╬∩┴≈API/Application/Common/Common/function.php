<?php
function P($data){
	echo "<pre>";
	print_r($data);
	echo "</pre>";
}

function V($data){
	echo "<pre>";
	var_dump($data);
	echo "</pre>";
}