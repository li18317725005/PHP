-- phpMyAdmin SQL Dump
-- version 3.3.7
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 03 月 01 日 14:36
-- 服务器版本: 5.6.30
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ceshi`
--

-- --------------------------------------------------------

--
-- 表的结构 `t_wxpay`
--

CREATE TABLE IF NOT EXISTS `t_wxpay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `orderNo` varchar(25) NOT NULL COMMENT '支付订单流水号',
  `money` float(10,2) NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '支付状态',
  `addtime` datetime NOT NULL COMMENT '数据添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderNo` (`orderNo`) COMMENT '支付流水订单号唯一'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='微信订单支付订单表' AUTO_INCREMENT=35 ;

--
-- 转存表中的数据 `t_wxpay`
--

