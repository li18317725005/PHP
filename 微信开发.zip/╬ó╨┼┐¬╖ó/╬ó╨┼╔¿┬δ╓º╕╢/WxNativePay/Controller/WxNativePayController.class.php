<?php
/**
 * 微信扫码支付
 * User: xiafan
 * Date: 2017/2/23
 * Time: 13:32
 */
namespace WxNativePay\Controller;
use Think\Controller;
vendor('WwpayAPI_v1.WwWxNativeOrderObject');
vendor('WxpayAPI_php_v3.lib.WxPay#Data');
vendor('WxpayAPI_php_v3.lib.WxPay#Notify');
vendor('WwpayAPI_v1.WwWxNativePayJsApi');
class WxNativePayController extends Controller {

    public function recharge() {
        $description = "支付";
        $outTradeNo = date("YmdHis")."-".mt_rand(1000,9999);
        $totalFee = 0.01;
        $wwwxOrderObj = new \WwWxNativeOrderObject();
        $wwwxOrderObj->setDescription($description);
        $wwwxOrderObj->setOutTradeNo($outTradeNo);
        $wwwxOrderObj->setTotalFee($totalFee*100);      //钱数 单位：分
        //$notify_url  可以根据程序url设置进行更改
        $notify_url = 'http://'.$_SERVER['HTTP_HOST'].'/WxNativePay/WxNativePay/notify';
        $wwwxNativePJsApi = new \WwWxNativePayJsApi();
        $jsApiParameters = $wwwxNativePJsApi->buildPackageInfo($notify_url, $wwwxOrderObj);
        //生成充值记录
       // $WxPayOrder = new IndexController();
       // $WxPayOrder->WxPayOrder($outTradeNo, $totalFee,$openId);
        return $jsApiParameters;
    }

    public function notify(){

        // TODO: 验证微信

        \Think\Log::write("function Native notify");

        $notify = new WxWxNativeNotifyCallBack();

        $notify->Handle(false);

    }



}



class WxWxNativeNotifyCallBack extends \WxPayNotify{
//重写回调处理函数
    public function NotifyProcess($data, &$msg) {
        //判断微信官方返回支付订单状态
        if($data['return_code'] == 'SUCCESS'){
            \Think\Log::write("NotifyProcess");
            \Think\Log::write(print_r($data,true));
        }
        return true;
    }
}