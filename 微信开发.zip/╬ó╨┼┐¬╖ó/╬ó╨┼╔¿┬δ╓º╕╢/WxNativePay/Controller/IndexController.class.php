<?php
namespace WxNativePay\Controller;
use Common\Controller\HomebaseController;
use Think\Controller;
use WxNativePay\Controller\WxNativePayController;

vendor("WxpayAPI_php_v3.example.phpqrcode.phpqrcode");

class IndexController extends HomebaseController{
	
	function index(){
	    $WxNativePay = new WxNativePayController();
        $img = $WxNativePay->recharge();
        $url = U('WxNativePay/Index/phpqrcode',array('url'=>urlencode($img['code_url'])));
        $this->assign('img_url',$url);
        $this->display();
	}

    /**
     * 处理二维码
     */
    public function phpqrcode(){
        $url = urldecode($_GET['url']);
        \QRcode::png($url);
    }
}