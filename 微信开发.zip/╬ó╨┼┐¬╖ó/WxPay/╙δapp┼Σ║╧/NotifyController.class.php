<?php
/**
 * 支付回调控制器
 * @author 李海江<18317725005@126.com>
 */
namespace App\Controller;

use App\Service\User\Pay\Pay;
use OaLibs\Third\Wxpay\lib\WxPayNotify;

class NotifyController {
    private $paySvc;

    public function __construct() {
        $this->paySvc = new Pay();
    }

    /**
     * 支付宝回调
     */
    public function alipay() {
        $this->paySvc->notifyUrl();
    }
    
    /**
     * 微信回调
     */
    public function wechat() {
        $notify = new WwWxPayNotifyCallBack();
        $notify->Handle(false);
    }
}

/**
 * 微信支付回调类
 */
class WwWxPayNotifyCallBack extends WxPayNotify {
    public function NotifyProcess($data, &$msg) {
        //判断微信官方返回支付订单状态
        if($data['return_code'] == 'SUCCESS' && $data['result_code'] == 'SUCCESS'){
            //支付成功后操作
            $payData = array(
                'out_trade_no' => $data['out_trade_no'],
                'money' => $data['total_fee'] / 100,
                'trade_no' => $data['transaction_id'],
            );
            $paySvc = new Pay();
            $paySvc->wechatNotifyUrl($payData);
        }
        return true;
    }
}
