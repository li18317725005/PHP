<?php
/**
 * 支付配置类
 * @author 李海江
 * @date 2017/11/24
 */
namespace App\Service\User\Pay;

class Config {
    /**
     * 支付宝配置参数
     */
    const SellerPid = '2088821762094878'; //商家id
    const TimeoutExpress = '30m'; //超时时间
    const GatewayUrl = 'https://openapi.alipay.com/gateway.do'; //网关
    const AppId = '2017112400134521'; //应用APPID
    //支付宝公钥
    const AlipayrsaPublicKey = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjnlqFBOwZ16LWKIdD8mjyWxVR2IRuzlflZleAQLei52rHYWitKdaa9hClk+X1yTnZVx3KiLQJtAqjncezbi7TPJWEhpOHXUVzCF7iqHh0/JC53J3XbHnaPf0zZbd+3lEsBcfSpd+ZkDnYeH3oBhRIBscZghmBARUccYnAQwxK42CP3Xo2kbWN5Nm/OBy5+KO5w7usCcgHpjL/i5J7ic68VT9zDnWizQdte2raQgAWUDG1Qlx6FAcUUcofQ/scKRksyLb6k8pUGLNZ6clhm6KguXmkg/ee4fPeT1tJSCm/rxO5vmJPSfTAkrIAxaXtntGeIXzTtEeRE3ClXw02hTr1wIDAQAB';
    //应用公钥
//    const ApplyPublicKey = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhdg3frRqJFxeZBvOvBQc5SL4HaVjfpEqZogEJ7WswVZwA/SgYnAvj+x5IZJ6wthm+xxVTTcbD2jX87j19kAKkP7Ef6XZ0u+TnBAJfQ2wfaFZchBIhZ5H/o+Iqg7eppGeaJEONEXSiGuyTIlX6Y36a8Lp30m5pKz1r2QbllxhLk5jLbrFzehfYM0VaStnyeUSFIjTa0G4MTahCkCX61AgI/LJg40zzjnlnVz04c/87gmh/wrcIDED1lRnHztqdnYbcIUL7IpeUrNC+0BxNI0cdjZo85yaSbXSEdYUhKFicb46V55rOH5H8J8UxPLZjhUFi0M+oEa5nq0eBdhviptQ5QIDAQAB';
    //应用私钥
    const RsaPrivateKey = 'MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCF2Dd+tGokXF5kG868FBzlIvgdpWN+kSpmiAQntazBVnAD9KBicC+P7HkhknrC2Gb7HFVNNxsPaNfzuPX2QAqQ/sR/pdnS75OcEAl9DbB9oVlyEEiFnkf+j4iqDt6mkZ5okQ40RdKIa7JMiVfpjfprwunfSbmkrPWvZBuWXGEuTmMtusXN6F9gzRVpK2fJ5RIUiNNrQbgxNqEKQJfrUCAj8smDjTPOOeWdXPThz/zuCaH/CtwgMQPWVGcfO2p2dhtwhQvsil5Ss0L7QHE0jRx2NmjznJpJtdIR1hSEoWJxvjpXnms4fkfwnxTE8tmOFQWLQz6gRrmerR4F2G+Km1DlAgMBAAECggEAfK9bo1F2v8C8vg2ZnWQvNtZIxXVZJoMdOL7lAAkikklvuH+fGZTg+faVMU0/x1vJM4zFelUnhEdrRcS8fVZTgZeUfkWGkhZVMEFQVYr3K1Gv/a5loPQ+pUoZSjLn/8wQAeF/lfqlkiihxOL9XrnA27qMHFKV+m6VwXpEqOIONg+52ASFJWcnYJZmoxZHYlwUxQi4eMWDSrPZ0Xi/JoYjxuJ+t5og5SOikvCqx/ofEv+hsXBM18FAsbkq/MF6v5190yRyRQxpWVxpmyRiRXiMBoF+ZmohdLxFAHxGAmOiNHvMTYlrML206O7LBlwTxh98Uh3oK2c0rliI4SNj3hAj0QKBgQDc124qDF2s1emIDrTMrwYIgEHpdfdgzN4P0LgDQN0nZ8oyPkfoijVpUn98Q1XzAZhoGMUc1q19VEqvUKoVE6N3yWW2fGhYLA+7kKQ0jEaWNFbiDpIAiurK4YaD+eW266Kk4Vp9+IPHpQfbFjmoAVD18k/NSVVXgrxZivbrxYZ76wKBgQCbJyiK3+61h3W2NIUWR7kvcnDBVCXYDbgaDMpPVLxb20//8IPna+rTHQMVuaT/UZHURRinJrOteZfyUYJkKHhQFtF8enQdpFM+MG9DgnEFGHjXYwBWFuRqHDqJwS/RVCrX9a3xd7F7sELTakuGgrSWG12Aw9D+uZ1Pc12cYstCbwKBgGo8vIM/1aR6d1B7eqBopidaw9pyZGHNzBmhl5QBFSKKvGs1KNSGADG9fRSjM+ql3tJc8B3ybB05eoAh9uASxXWvjd2etXeNIrhhWYzp2l8RqKYwyi22pkKZAWPlyIsZifF1c1ncPlDBZCkR5QScNX1LZvZji8mAW+lbf3NmX06nAoGBAIu12TYkq4lfL0ohRO5pK4JkJNCR+3nv8KXUeqCxBuQYOpOXes97R/tOlqaLgt4+D3j7t1Vc7lL5uS+E4ktafexwf7b9dW3zuNm5N5es8CTMgpRBG95pwskiHjxJb8upZOMO4dEcHP/qGmLRxqybKg45GhuHOL0HW3Zdxh+6fpmVAoGAevzFFW4Hd7Z7hErY+nbW1jzMWcicuU12/kwkXAWK62g0pmXhcj4fusfWJNv7ilGYg6HRXIaGMG2CEnXKy0fNwvl1fhPxs0hL4ebqWe7LZ18CSxrjtSispgg6C8bDuzS3eVaVaJAoiA5IjMR4lUwd3umwm7jPy/cIKlSuY5OEROg=';
    const Charset = 'UTF-8';
    const SignType = 'RSA2';
    const NotifyUrl = 'http://buildnw.gcezw.com/App/Notify/alipay';
    const ReturnUrl = '';
    
    
    /**
     * 微信支付配置常量
     */
    const wechatNotifyUrl = 'http://buildnw.gcezw.com/App/Notify/wechat';
    const APPID = 'wx2e1ee2f76136473f'; //appid
    const MCHID = '1493680312'; //商户号
    const KEY = '46de57d6445c0b807bfc162dbb8bda08';
    const APPSECRET = '3d3427bedf8bfbd3fa626080776dba7e';
}

