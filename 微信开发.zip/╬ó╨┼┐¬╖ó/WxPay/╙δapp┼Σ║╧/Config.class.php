<?php
/**
 * 支付配置类
 * @author 李海江
 * @date 2017/11/24
 */
namespace App\Service\User\Pay;

class Config {
    /**
     * 支付宝配置参数
     */
    const SellerPid = ''; //商家id
    const TimeoutExpress = '30m'; //超时时间
    const GatewayUrl = 'https://openapi.alipay.com/gateway.do'; //网关
    const AppId = ''; //应用APPID
    //支付宝公钥
    const AlipayrsaPublicKey = '';
    //应用公钥
//    const ApplyPublicKey = 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhdg3frRqJFxeZBvOvBQc5SL4HaVjfpEqZogEJ7WswVZwA/SgYnAvj+x5IZJ6wthm+xxVTTcbD2jX87j19kAKkP7Ef6XZ0u+TnBAJfQ2wfaFZchBIhZ5H/o+Iqg7eppGeaJEONEXSiGuyTIlX6Y36a8Lp30m5pKz1r2QbllxhLk5jLbrFzehfYM0VaStnyeUSFIjTa0G4MTahCkCX61AgI/LJg40zzjnlnVz04c/87gmh/wrcIDED1lRnHztqdnYbcIUL7IpeUrNC+0BxNI0cdjZo85yaSbXSEdYUhKFicb46V55rOH5H8J8UxPLZjhUFi0M+oEa5nq0eBdhviptQ5QIDAQAB';
    //应用私钥
    const RsaPrivateKey = 'Wxpay/';
    const Charset = 'UTF-8';
    const SignType = 'RSA2';
    const NotifyUrl = '';
    const ReturnUrl = '';
    
    
    /**
     * 微信支付配置常量
     */
    const wechatNotifyUrl = '';
    const APPID = ''; //appid
    const MCHID = ''; //商户号
    const KEY = '';
    const APPSECRET = '';
}

