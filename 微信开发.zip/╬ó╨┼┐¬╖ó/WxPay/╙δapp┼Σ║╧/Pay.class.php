<?php
/**
 * 支付宝支付service类
 * @author 李海江
 * @date 2017/11/24
 */
namespace App\Service\User\Pay;

use App\Service\User\UserConst;
use OaLibs\Service\Order\IntegralOrder;
use OaLibs\Service\Pay\PayLog;
use OaLibs\Service\Pay\PayIntegral;
use OaLibs\Service\Role\User\UserFactory;
use OaLibs\Service\IntegralLog\IntegralLog;
use App\Service\User\Pay\Config;
use OaLibs\Third\Aop\AopClient;
use OaLibs\Third\Aop\request\AlipayTradeAppPayRequest;
use OaLibs\Third\Wxpay\lib\WxPayUnifiedOrder;
use OaLibs\Third\Wxpay\lib\WxPayApi;

class Pay extends Base {
    private $integralOrderSvc;
    private $payLogSvc;
    private $userSvc;
    private $integralLogSvc;

    public function __construct() {
        $this->integralOrderSvc = new IntegralOrder();
        $this->payLogSvc = new PayLog();
        $factory = new UserFactory();
        $this->userSvc = $factory->createRole();
        $this->integralLogSvc = new IntegralLog();
    }

    /**
     * 分发器
     */
    public function index($type, $user, $data) {
        switch ($type) {
            case UserConst::CreateOrder: //生成积分订单, 支付记录, 返回app所需参数
                return $this->createOrder($data, $user['id']);
        }
    }

    /**
     * 生成积分订单, 支付记录, 返回app所需参数
     */
    public function createOrder($data, $uid) {
        if (!$data['money'] || $data['money'] < 0.01 || !$data['type']) return array('code' => -100, 'msg' => '参数有误');
        $this->payLogSvc->payLogMd->startTrans();
        $order_no = get_order_no();
        $name = $data['money'] . '元积分';
        //生成积分订单
        $res1 = $this->integralOrderSvc->addIntegralOrder($uid, $name, $order_no, $data['money'], $data['type']);
        //生成支付记录
        $res2 = $this->payLogSvc->addPayLog($uid, $order_no, $data['money'], $data['type']);
        if ($res1['code'] == 200 && $res2['code'] == 200) {
            $this->payLogSvc->payLogMd->commit();
            switch ($data['type']) {
                case 1: //支付宝支付
                    $return = $this->alipayCreateOrder($data['money'], $order_no);
                    return array('code' => 200, 'msg' => '创建订单成功', 'data' => array('orderString' => $return));
                case 2: //微信支付
                    $return = $this->wechatCreateOrder($data['money'], $order_no);
                    if ($return == -1) return array('code' => -1, 'msg' => '创建订单失败');
                    return array('code' => 200, 'msg' => '微信支付创建订单成功', 'data' => $return);
            }
        } else {
            $this->payLogSvc->payLogMd->rollback();
            return array('code' => -1, 'msg' => '创建订单失败');
        }
    }
    
    //////////////////////////////////////////////////支付宝开始/////////////////////////////////////////////////////////////////////////
    /**
     * 请求支付宝api下订单
     */
    public function alipayCreateOrder($money, $order_no) {
        //请求参数说明
        $timeout_express = Config::TimeoutExpress; //设置超时时间
        $seller_id       = Config::SellerPid; //商家id
        $total_amount    = $money; //订单总金额
        $subject         = '济济修建'.$money.'元积分'; //商品的标题
        $out_trade_no    = $order_no; //商户网站唯一订单号            
        $body            = '积分购买'; //对一笔交易的具体描述信息
        $time            = time();
        
        $aop = new AopClient();
        $aop->gatewayUrl =  Config::GatewayUrl; //支付宝网关
        $aop->appId = Config::AppId; //支付宝分配给开发者的应用Id
        $aop->alipayrsaPublicKey = Config::AlipayrsaPublicKey; //请填支付宝公钥，一行字符串
        $aop->rsaPrivateKey =  Config::RsaPrivateKey; //请填写开发者私钥去头去尾去回车，一行字符串//例图↓
        $aop->charset =  Config::Charset;
        $aop->signType = Config::SignType; //签名类型

        $request = new AlipayTradeAppPayRequest();
        //SDK已经封装掉了公共参数，这里只需要传入业务参数
        $bizcontent = "{\"timeout_express\":\"$timeout_express\","
                    . "\"seller_id\": \"$seller_id\","
                    . "\"product_code\": \"QUICK_MSECURITY_PAY\","
                    . "\"total_amount\": \"$total_amount\","
                    . "\"subject\": \"$subject\","
                    . "\"out_trade_no\":\"$out_trade_no\","
                    . "\"body\":\"$body\""
                    . "}";

        $request->setNotifyUrl(Config::NotifyUrl);
        $request->setBizContent($bizcontent);

        //这里和普通的接口调用不同，使用的是sdkExecute
        $response = $aop->sdkExecute($request);

        //echo htmlspecialchars($response);//就是orderString 可以直接给客户端请求，无需再做处理。
        //$return_url =  Config::ReturnUrl;
        return $response;
    }
    
    /**
     * 支付宝异步回调处理逻辑
     */
    public function notifyUrl() {
        $aop = new AopClient;
        $aop->alipayrsaPublicKey = Config::AlipayrsaPublicKey; //请填写支付宝公钥，一行字符串
        $flag = $aop->rsaCheckV1($_POST, NULL, Config::SignType); //是否支付成功
        if ($flag) {
            $payLog = $this->payLogSvc->getPayLogByOrderNo($_POST['out_trade_no']); //支付记录
            if ($payLog['status'] == 10) { //支付状态已更新
               echo 'success';
            }else{
               //成功后的操作
               $this->paySuccess($payLog, $_POST['out_trade_no'], $_POST['trade_no']);
               echo 'success';
            }
        }else{
            echo 'fail';
        }
    }
    //////////////////////////////////////////////////支付宝结束/////////////////////////////////////////////////////////////////////////
    
    //////////////////////////////////////////////////微信支付开始//////////////////////////////////////////////////////////////////////
    /**
     * 微信下订单
     */
    public function wechatCreateOrder($money, $order_no) {
        $input = new WxPayUnifiedOrder();
        $input->SetBody($money . '元积分');  //设置商品或支付单简要描述
        $input->SetAttach('');    //设置附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
        $input->SetOut_trade_no($order_no);  //设置商户系统内部的订单号,32个字符内、可包含字母, 其他说明见商户订单号
        $input->SetTotal_fee($money * 100);  //设置订单总金额，只能为整数，详见支付金额
        $input->SetTime_start(date("YmdHis"));  //设置订单生成时间，格式为yyyyMMddHHmmss
        $input->SetTime_expire(date("YmdHis", time() + 60*10));    //设置订单失效时间，格式为yyyyMMddHHmmss
        $input->SetGoods_tag("");  //设置商品标记，代金券或立减优惠功能的参数，说明详见代金券或立减优惠
        $input->SetNotify_url(Config::wechatNotifyUrl);  //设置接收微信支付异步通知回调地址
        $input->SetTrade_type("APP");  //设置类型如下：JSAPI，NATIVE，APP
        $input->SetAppid(Config::APPID);
        $input->SetMch_id(Config::MCHID);
        $order_data = WxPayApi::unifiedOrder($input);  //统一下单
        if ($order_data['return_code'] == 'SUCCESS' && $order_data['result_code'] == 'SUCCESS') {
            $order_data['timestamp'] = time();
            $str = 'appid='.$order_data['appid'].'&noncestr='.$order_data['nonce_str'].'&package=Sign=WXPay&partnerid='.Config::MCHID.'&prepayid='.$order_data['prepay_id'].'&timestamp='.$order_data['timestamp'];
            //重新生成签名
            $order_data['sign'] = strtoupper(md5($str.'&key='.Config::KEY));
            //将$order_data数据返回给APP端调用
            return $order_data;
        } else {
            return -1;
        }
    }
    
    /**
     * 微信支付回调
     */
    public function wechatNotifyUrl($data) {
        $payLog = $this->payLogSvc->getPayLogByOrderNo($data['out_trade_no']); //支付记录
        if ($payLog['status'] == 10) { //支付状态已更新
           return true;
        }else{
           //成功后的操作
           $this->paySuccess($payLog, $data['out_trade_no'], $data['trade_no']);
           return true;
        }
    }
    //////////////////////////////////////////////////微信支付结束//////////////////////////////////////////////////////////////////////
    
    /**
     * 支付成功后的操作
     * @param type $payLog  支付记录信息
     * @param type $order_no 内部订单号
     * @param type $trade_no 支付宝交易号
     */
    private function paySuccess($payLog, $order_no, $trade_no) {
        //开启事务
        $this->payLogSvc->payLogMd->startTrans();
        //改变支付记录
        $pl_data['trade_no'] = $trade_no;
        $pl_data['status'] = 10;
        $pl_data['success_time'] = date('Y-m-d H:i:s');
        $res1 = $this->payLogSvc->savePayLog(array('order_no' =>$order_no), $pl_data);
        if ($res1) {
            //改变积分订单状态
            $io_data['status'] = 10;
            $io_data['utime'] = date('Y-m-d H:i:s');
            $res2 = $this->integralOrderSvc->saveIntegralOrder(array('order_no' => $order_no), $io_data);
            //给用户增加积分
            $payIntegralSvc = new PayIntegral();
            $integral = $payIntegralSvc->getIntegral($payLog['money']) ?: ($payLog['money'] * 100);
            $res3 = $this->userSvc->setUserIntegral(array('id' => $payLog['u_id']), 'integral', $integral);
            //新增积分记录
            $il_data['order_no'] = $order_no;
            $il_data['u_id'] = $payLog['u_id'];
            $il_data['integral'] = $integral;
            $il_data['price'] = $payLog['money'];
            $il_data['type'] = 15;
            $res4 = $this->integralLogSvc->addIntegralLog($il_data);
            //判断
            if ($res2 && $res3 && $res4) {
                $this->payLogSvc->payLogMd->commit();
            } else {
                $this->payLogSvc->payLogMd->rollback();
                if (!$res2) \Think\Log::write('----222----'.$order_no.'--Change IntegralOrder Fail----------');
                if (!$res3) \Think\Log::write('----333----'.$order_no.'--SetInc UserIntegral Fail----------');
                if (!$res4) \Think\Log::write('----444----'.$order_no.'--Add IntegralLog Fail----------');
            }
        } else {
            $this->payLogSvc->payLogMd->rollback();
            \Think\Log::write('----111----'.$order_no.'--Change PayLog Fail----------');
        }
    }
 
    
}

