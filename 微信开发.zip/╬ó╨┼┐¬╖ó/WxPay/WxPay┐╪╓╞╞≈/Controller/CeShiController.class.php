<?php
/**
 * 微信支付入口接口（测试入口）
 * User: xiafan
 * Date: 2017/2/21
 * Time: 9:58
 */

namespace WxPay\Controller;
use Think\Controller;

class CeShiController extends Controller{

    public function index(){
        $openid = 'oaeRbuJkcebDI9djsC-zfAC1m544';
        $admin_uuid = '882791F7-B9ED-6B45-08EC-0B02D6C80527';
        $WxPay = new IndexController();
        $WxPay->index(0.01,$openid);
    }



}