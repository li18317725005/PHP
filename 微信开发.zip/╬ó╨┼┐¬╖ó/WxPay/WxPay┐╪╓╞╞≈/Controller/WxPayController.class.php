<?php
/**
 * Created by PhpStorm.
 * User: xiafan
 * Date: 2017/2/18
 * Time: 13:32
 */
namespace WxPay\Controller;
use Think\Controller;
vendor('WwpayAPI_v1.WwWxOrderObject');
vendor('WxpayAPI_php_v3.lib.WxPay#Data');
vendor('WxpayAPI_php_v3.lib.WxPay#Notify');
vendor('WwpayAPI_v1.WwWxPayJsApi');
/**
 * 微信支付
 * @author: xiafan   <ak911007@163.com>

 * @date: 2017.2.18

 */
class WxPayController extends Controller {
    /**
     * 微信支付成功后，在回调URL中，比如：index.php/Home/FinanceRecharge/notify
     * 由于是回调，会出现没有openid，而导致重定向
     * 因此对于此类不能对openid的检查放置到构造函数中
     * 对于openid的检查，此处采用php类的魔法函数__call()进行，只需把有openid检查需求
     * 的函数可见性设置为private即可。
     */
    private $uid;
    private $openid;
    public function __construct(){
        parent::__construct();
    }
    //支付调用
    public function recharge($money,$openId) {
        $description = "支付";
        $outTradeNo = date("YmdHis")."-".mt_rand(1000,9999);
        $totalFee = $money;
        $wwwxOrderObj = new \WwWxOrderObject();
        $wwwxOrderObj->setDescription($description);
        $wwwxOrderObj->setOutTradeNo($outTradeNo);
        $wwwxOrderObj->setTotalFee($totalFee*100);      //钱数 单位：分
        //$notify_url  可以根据程序url设置进行更改
        $notify_url = 'http://'.$_SERVER['HTTP_HOST'].'/WxPay/WxPay/notify';
        $wwwxPJsApi = new \WwWxPayJsApi();
        $jsApiParameters = $wwwxPJsApi->buildPackageInfo($openId, $notify_url, $wwwxOrderObj);
        //生成充值记录
        $WxPayOrder = new IndexController();
        $WxPayOrder->WxPayOrder($outTradeNo, $totalFee,$openId);
        return $jsApiParameters;
    }
    public function notify(){

        // TODO: 验证微信

        \Think\Log::write("function notify");

        $notify = new WwWxPayNotifyCallBack();

        $notify->Handle(false);

    }
   /**
     * 以数组的方式传递参数
     */
    /*
    public function __call($method, $value) {
        // \Think\Log::write("call method was invoked!")
        //$this->uid = $wx_user_info["uid"];
      // $this->openid = $wx_user_info["openid"];
        return call_user_func_array(array($this, "$method"), $value);
    }*/
    
    
    public function ceshi(){
       $wwwxPJsApi = new \JsApiPay();
       $a = $wwwxPJsApi->a();

        var_dump($a);
    }
}



class WwWxPayNotifyCallBack extends \WxPayNotify{
    //重写回调处理函数
    public function NotifyProcess($data, &$msg) {
        //判断微信官方返回支付订单状态
        if($data['return_code'] == 'SUCCESS'){
            $order_id = $data['out_trade_no'];
            $payInfo = D('WxPay')->getWxPayOrder($order_id);          //根据支付订单号获取支付订单信息
            \Think\Log::write(print_r($payInfo,true));
            //如果判断支付订单状态是否改变过
            if($payInfo["status"]==1) {
                //改变了 ，直接返回
                return true;
            } else {
                //如果没有，改变状态
                /* 检查支付的金额是否相符 */
                if ($payInfo["money"] == $data['total_fee']/100) {
                    D('WxPay')->setWxPayOrderStatus($order_id);     //改变订单状态
                }
            }
        }
        return true;
    }
}