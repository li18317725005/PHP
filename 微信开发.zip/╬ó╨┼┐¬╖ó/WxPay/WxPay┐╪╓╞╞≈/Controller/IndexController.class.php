<?php
/**
 * 微信支付入口接口
 * User: xiafan
 * Date: 2017/2/21
 * Time: 9:58
 */
namespace WxPay\Controller;
use Common\Controller\HomebaseController;
use Think\Controller;

//此处继承HomebaseController为了适应ThinkCMF这个框架
class IndexController extends HomebaseController{
    /**
     * 微信支付入口
     * 注：此处一定用传值，不要用session中的值，否则有可能会出现异常错误
     * @param $money
     * @param $openid
     */
    function index($money,$openid){
        if(!$openid || !$money > 0){
            $this->error("参数错误！");
        }
        $jsApiParameters=R('WxPay/WxPay/recharge',array('money'=>$money,'openid'=>$openid));
        $this->assign("jsApiParameters", $jsApiParameters);
        //可以根据项目模板的位置进行放置，然后进行调用
        $this->display(":recharge");
	}


    /**
     * 添加微信支付订单信息
     * @param $outTradeNo
     * @param $totalFee
     * @param $openid
     */
    public function WxPayOrder($outTradeNo, $totalFee,$openid) {
        $wx_pay_obj = new \WxPay\Common\Wx_pay($openid,$outTradeNo,$totalFee);
        D('WxPay')->wxPayOrderAdd($wx_pay_obj);
    }

    /**
     * 微信支付配置
     * @param $mo
     * @return string
     */
    public function configs($mo){
        /**
         * 此可以根据需求进行更改，如：从数据库中去查
         */

        switch ($mo){
            case 'appid':$data = 'wx87d6f46cbcb4e1c8';  //APPID：绑定支付的APPID（必须配置，开户邮件中可查看）
                break;
            case 'mchid':$data = '1328516701';     //MCHID：商户号（必须配置，开户邮件中可查看）
                break;
            case 'key':$data =  'ZHENGZHOUhenanweiwang12345678900';    //KEY：商户支付密钥，参考开户邮件设置（必须配置，登录商户平台自行设置）
                                                                      // 设置地址：https://pay.weixin.qq.com/index.php/account/api_cert
                break;
            case 'appsecret':$data = '0f7ee61ea1fdd990503e2fa5794bcfc7';   //APPSECRET：公众帐号secert（仅JSAPI支付的时候需要配置， 登录公众平台，进入开发者中心可设置）
                break;
            /**
             * TODO：设置商户证书路径
             * 证书路径,注意应该填写绝对路径（仅退款、撤销订单时需要，可登录商户平台下载，
             * API证书下载地址：https://pay.weixin.qq.com/index.php/account/api_cert，下载之前需要安装商户操作证书）
             * @var path
             */
            case 'sslcert_path':$data = '/www/web/hongbao/public_html/simplewind/Core/Library/Vendor/WxpayAPI_php_v3/lib/cert/apiclient_cert.pem';
                break;
            case 'sslkey_path':$data =  '/www/web/hongbao/public_html/simplewind/Core/Library/Vendor/WxpayAPI_php_v3/lib/cert/apiclient_key.pem';
                break;
        }
        return $data;

    }
}


