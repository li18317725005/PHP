<?php
/**
 * 微信支付订单数据操作
 * User: xiafan
 * Date: 2017/2/22
 * Time: 10：00
 */
namespace WxPay\Model;
use Common\Model\CommonModel;
class WxPayModel extends CommonModel{
    private $wxpay;
    public function __construct(){
        $this->wxpay = M('wxpay');
    }

    /**
     * 添加微信支付订单信息
     * @param $WxPayOrder_obj
     * @return bool
     */
    public function wxPayOrderAdd($WxPayOrder_obj){
        $data = $WxPayOrder_obj->to_array();
        $data['addtime'] = date('Y-m-d H:i:s');
        $return = $this->wxpay->add($data);
        if($return){
            return true;
        }else{
            return false;
        }
    }

    /**
     * 根据唯一订单流水号查找支付信息
     * @param $orderNo
     */
    public function getWxPayOrder($orderNo){
        $where['orderNo'] = $orderNo;
        $data = $this->wxpay->where($where)->find();
        if($data){
            return $data;
        }else{
            return false;
        }
    }

    /**
     * 根据支付流水订单号改变订单的状态
     * @param $orderNo
     * @return bool
     */
    public function setWxPayOrderStatus($orderNo){
        $where['orderNo'] = $orderNo;
        $data['status'] = 1;
        $return = $this->wxpay->where($where)->save($data);
        if($return){
            return true;
        }else{
            return false;
        }
    }


}
