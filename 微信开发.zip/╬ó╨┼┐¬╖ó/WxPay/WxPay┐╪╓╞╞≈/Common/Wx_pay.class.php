<?php
/**
 * 微信支付订单的实体类
 * User: xiafan
 * Date: 2016/12/15
 * Time: 15:47
 */
namespace WxPay\Common;

class Wx_pay extends Base
{
    protected $openid;               //用户唯一标识
    protected $orderNo;              //支付订单流水号
    protected $money;                //支付金额
    protected $status;               //支付状态

    public function __construct($openid,
                                $orderNo,
                                $money,
                                $status=0
    ){
        $this->openid = $openid;
        $this->orderNo = $orderNo;
        $this->money = $money;
        $this->status = $status;
    }
}