<?php

/**
 * 微信红包 (非官方)
 * @author: zhangyq <289525496@qq.com>
 * @date: 2016.08.01
 */

require_once "WxPay.Data.php";
require_once "WxPay.Config.php";
require_once "WxPay.Exception.php";



 /**
 * 红包输入对象
 */
class WxPayRedPack extends WxPayDataBase {
	/**
	* 设置随机字符串，不长于32位。推荐随机数生成算法
	* @param string $value 
	**/
	public function SetNonce_str($value)
	{
		$this->values['nonce_str'] = $value;
	}
	/**
	* 获取随机字符串，不长于32位。推荐随机数生成算法的值
	* @return 值
	**/
	public function GetNonce_str()
	{
		return $this->values['nonce_str'];
	}
	/**
	* 判断随机字符串，不长于32位。推荐随机数生成算法是否存在
	* @return true 或 false
	**/
	public function IsNonce_strSet()
	{
		return array_key_exists('nonce_str', $this->values);
	}
	
	/**
	* 商户订单号（每个订单号必须唯一） 组成：mch_id+yyyymmdd+10位一天内不能重复的数字。
	* 接口根据商户订单号支持重入，如出现超时可再调用。
	* 
	* @param string $value 
	*/
	public function SetMch_billno($value)
	{
		$this->values['mch_billno'] = $value;
	}
	/**
	* 获取商户订单号
	* @return 值
	*/
	public function GetMch_billno()
	{
		return $this->values['mch_billno'];
	}
	/**
	* 判断商户订单号是否存在
	* @return true 或 false
	**/
	public function IsMch_billnoSet()
	{
		return array_key_exists('mch_billno', $this->values);
	}
	
	/**
	* 设置微信支付分配的商户号
	* @param string $value 
	**/
	public function SetMch_id($value)
	{
		$this->values['mch_id'] = $value;
	}
	/**
	* 获取微信支付分配的商户号的值
	* @return 值
	**/
	public function GetMch_id()
	{
		return $this->values['mch_id'];
	}
	/**
	* 判断微信支付分配的商户号是否存在
	* @return true 或 false
	**/
	public function IsMch_idSet()
	{
		return array_key_exists('mch_id', $this->values);
	}

	/**
	* 设置微信分配的公众账号ID
	* @param string $value 
	**/
	public function SetWxappid($value)
	{
		$this->values['wxappid'] = $value;
	}
	/**
	* 获取微信分配的公众账号ID的值
	* @return 值
	**/
	public function GetWxappid()
	{
		return $this->values['wxappid'];
	}
	/**
	* 判断微信分配的公众账号ID是否存在
	* @return true 或 false
	**/
	public function IsWxappidSet()
	{
		return array_key_exists('wxappid', $this->values);
	}
	
	/**
	* 设置商户名称
	* @param string $value 
	**/
	public function SetSend_name($value)
	{
		$this->values['send_name'] = $value;
	}
	/**
	* 获取商户名称的值
	* @return 值
	**/
	public function GetSend_name()
	{
		return $this->values['send_name'];
	}
	/**
	* 判断商户名称是否存在
	* @return true 或 false
	**/
	public function IsSend_nameSet()
	{
		return array_key_exists('send_name', $this->values);
	}
	
	/**
	* 设置接受红包的用户openid(在wxappid下的openid)
	* @param string $value 
	*/
	public function SetRe_openid($value)
	{
		$this->values['re_openid'] = $value;
	}
	/**
	* 获取接受红包的用户openid
	* @return 值
	*/
	public function GetRe_openid()
	{
		return $this->values['re_openid'];
	}
	/**
	* 判断接受红包的用户openid是否存在
	* @return true 或 false
	*/
	public function IsRe_openidSet()
	{
		return array_key_exists('re_openid', $this->values);
    }
	
	/**
	* 设置付款金额，单位分
	* @param string $value 
	*/
	public function SetTotal_amount($value)
	{
		$this->values['total_amount'] = $value;
	}
	/**
	* 获取付款金额，单位为分
	* @return 值
	**/
	public function GetTotal_amount()
	{
		return $this->values['total_amount'];
	}
	/**
	* 判断付款金额是否存在
	* @return true 或 false
	*/
	public function IsTotal_amountSet()
	{
		return array_key_exists('total_amount', $this->values);
	}

    /**
	* 设置红包发放总人数
	* @param string $value 
	*/
	public function SetTotal_num($value)
	{
		$this->values['total_num'] = $value;
	}
	/**
	* 获取红包发放总人数
	* @return 值
	*/
	public function GetTotal_num()
	{
		return $this->values['total_num'];
	}
	
	/**
	* 判断红包方法总人数是否设置
	* @return true 或 false
	**/
	public function IsTotal_numSet()
	{
		return array_key_exists('total_num', $this->values);
	}

    /**
	* 设置红包祝福语
	* @param string $value 
	*/
	public function SetWishing($value)
	{
		$this->values['wishing'] = $value;
	}
	/**
	* 获取红包祝福语
	* @return 值
	*/
	public function GetWishing()
	{
		return $this->values['wishing'];
	}
	/**
	* 判断红包祝福语是否设置
	* @return true 或 false
	*/
	public function IsWishingSet()
	{
		return array_key_exists('wishing', $this->values);
    }

	/**
	* 设置调用接口的机器Ip地址。
	* @param string $value 
	*/
	public function SetClient_ip($value)
	{
		$this->values['client_ip'] = $value;
	}
	/**
	* 获取调用接口的机器IP地址的值
	* @return 值
	*/
	public function GetClient_ip()
	{
		return $this->values['client_ip'];
	}
	/**
	* 判断调用接口的机器IP地址是否设置
	* @return true 或 false
	*/
	public function IsClient_ipSet()
	{
		return array_key_exists('client_ip', $this->values);
    }

    /**
	* 设置活动名称
	* @param string $value 
	*/
	public function SetAct_name($value)
	{
		$this->values['act_name'] = $value;
	}
	/**
	* 获取活动名称的值
	* @return 值
	*/
	public function GetAct_name()
	{
		return $this->values['act_name'];
	}
	/**
	* 判断活动名称是否设置
	* @return true 或 false
	*/
	public function IsAct_nameSet()
	{
		return array_key_exists('act_name', $this->values);
	}

    /**
	* 设置备注信息
	* @param string $value 
	*/
	public function SetRemark($value)
	{
		$this->values['remark'] = $value;
	}
	/**
	* 获取备注信息的值
	* @return 值
	*/
	public function GetRemark()
	{
		return $this->values['remark'];
	}
	/**
	* 判断备注信息值是否设置
	* @return true 或 false
	**/
	public function IsRemarkSet()
	{
		return array_key_exists('remark', $this->values);
	}
}


/**
 * 接口调用结果类
 * @author zhangyq 
 */
class WxPayRedPackResults extends WxPayDataBase
{
	/**
	 * 
	 * 使用数组初始化
	 * @param array $array
	 */
	public function FromArray($array)
	{
		$this->values = $array;
	}
	
	/**
	 * 
	 * 使用数组初始化对象
	 * @param array $array
	 */
	public static function InitFromArray($array)
	{
		$obj = new self();
		$obj->FromArray($array);

        return $obj;
	}
	
	/**
	 * 
	 * 设置参数
	 * @param string $key
	 * @param string $value
	 */
	public function SetData($key, $value)
	{
		$this->values[$key] = $value;
	}
	
    /**
     * 将xml转为array
     * @param string $xml
     * @throws WxPayException
     */
	public static function Init($xml)
	{	
		$obj = new self();
		$obj->FromXml($xml);
		//fix bug 2015-06-29
		if($obj->values['return_code'] != 'SUCCESS'){
			 return $obj->GetValues();
		}
        return $obj->GetValues();
	}
}
 
class WxPayRedPackApi {
    
    /**
     * 企业付款，WxPayBusiness中partner_trade_no、openid、check_name、amount、desc必填
     * 
     * 当check_name为FORCE_CHECK时，re_user_name为必填  
     *   校验用户姓名选项，NO_CHECK：不校验真实姓名 
     *   FORCE_CHECK：强校验真实姓名（未实名认证的用户会校验失败，无法转账）
     *   OPTION_CHECK：针对已实名认证的用户才校验真实姓名（未实名认证用户不校验，可以转账成功）
     *
     * mch_appid、mchid、nonce_str、sign、spbill_create_ip不需要填入
     */ 
    public static function SendRedPack($inputObj, $timeOut=6) {

        $url = "https://api.mch.weixin.qq.com/mmpaymkttransfers/sendredpack"; 

        //检测必填参数
		if(!$inputObj->IsMch_billnoSet()) {
			throw new WxPayException("微信红包API中，mch_billno是必填参数！");
		}else if(!$inputObj->IsSend_nameSet()){
			throw new WxPayException("微信红包API中，send_name是必填参数！");
		}else if(!$inputObj->IsRe_openidSet()){
			throw new WxPayException("微信红包API中，re_openid是必填参数！");
		}else if(!$inputObj->IsTotal_amountSet()) {
			throw new WxPayException("微信红包API中，total_amount是必填参数！");
		}else if(!$inputObj->IsTotal_numSet()) {
			throw new WxPayException("微信红包API中，total_num是必填参数！");
        }else if(!$inputObj->IsWishingSet()) {
            throw new WxPayException("微信红包API中，wishing是必填参数！");
        } else if(!$inputObj->IsAct_nameSet()) {
            throw new WxPayException("微信红包API中，act_name是必填参数！");
        } else if(!$inputObj->IsRemarkSet()) {
            throw new WxPayException("微信红包API中，remark是必填参数！");
        }


        $inputObj->SetAppid(\WxPay\Controller\IndexController::configs('appid'));//公众账号ID   \WxPayConfig::APPID
        $inputObj->SetMch_id(\WxPay\Controller\IndexController::configs('mchid'));//商户号       \WxPayConfig::MCHID
        $inputObj->SetNonce_str(self::getNonceStr());//随机字符串
		$inputObj->SetClient_ip($_SERVER['REMOTE_ADDR']);  

		$inputObj->SetSign();//签名
		$xml = $inputObj->ToXml();    
		
		//var_dump($xml);
		//die();

		$response = self::postXmlCurl($xml, $url, true, $timeOut);
		$result = \WxPayRedPackResults::Init($response);
		
		// TODO: 
		return $result;
    }

	/**
	 * 以post方式提交xml到对应的接口url
	 * 
	 * @param string $xml  需要post的xml数据
	 * @param string $url  url
	 * @param bool $useCert 是否需要证书，默认不需要
	 * @param int $second   url执行超时时间，默认30s
	 * @throws WxPayException
	 */
	private static function postXmlCurl($xml, $url, $useCert = false, $second = 30) {
		\Think\Log::write($xml);
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		
		//如果有配置代理这里就设置代理
		if(WxPayConfig::CURL_PROXY_HOST != "0.0.0.0" 
			&& WxPayConfig::CURL_PROXY_PORT != 0){
			curl_setopt($ch,CURLOPT_PROXY, WxPayConfig::CURL_PROXY_HOST);
			curl_setopt($ch,CURLOPT_PROXYPORT, WxPayConfig::CURL_PROXY_PORT);
		}
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);//严格校验
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	
		if($useCert == true){
			//设置证书
			//使用证书：cert 与 key 分别属于两个.pem文件
            curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLCERT, \WxPay\Controller\IndexController::configs('sslcert_path'));      //WxPayConfig::SSLCERT_PATH
            curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLKEY, \WxPay\Controller\IndexController::configs('sslkey_path'));        //WxPayConfig::SSLKEY_PATH
		}
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		//运行curl
		$data = curl_exec($ch);
		\Think\Log::write("postXmlCurl:".$data);
		//返回结果
		if($data){
			curl_close($ch);
			return $data;
		} else { 
			$error = curl_errno($ch);
			curl_close($ch);
			throw new \WxPayException("curl出错，错误码:$error");
		}
	}
	
	
    /**
	 * 
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	public static function getNonceStr($length = 32) {
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {  
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
		} 
		return $str;
	}
}

