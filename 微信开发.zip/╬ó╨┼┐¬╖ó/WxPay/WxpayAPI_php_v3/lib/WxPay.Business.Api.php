<?php

require_once "WxPay.Business.Data.php";
require_once "WxPay.Config.php";
require_once "WxPay.Exception.php";

/**
 * 微信企业付款API (非官方)
 * @author: zhangyq <289525496@qq.com>
 * @date: 2016.05.14
 */
class WxPayBusinessApi {
    
    /**
     * 企业付款，WxPayBusiness中partner_trade_no、openid、check_name、amount、desc必填
     * 
     * 当check_name为FORCE_CHECK时，re_user_name为必填  
     *   校验用户姓名选项，NO_CHECK：不校验真实姓名 
     *   FORCE_CHECK：强校验真实姓名（未实名认证的用户会校验失败，无法转账）
     *   OPTION_CHECK：针对已实名认证的用户才校验真实姓名（未实名认证用户不校验，可以转账成功）
     *
     * mch_appid、mchid、nonce_str、sign、spbill_create_ip不需要填入
     */ 
    public static function BtoCPay($inputObj, $timeOut=6) {

        $url = "https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers"; 

        //检测必填参数
		if(!$inputObj->IsPartner_trade_noSet()) {
			throw new WxPayException("企业付款API中，partner_trade_no是必填参数！");
		}else if(!$inputObj->IsOpenidSet()){
			throw new WxPayException("企业付款API中，openid是必填参数！");
		}else if(!$inputObj->IsAmountSet()) {
			throw new WxPayException("企业付款API中，amount是必填参数！");
		}else if(!$inputObj->IsDescSet()) {
			throw new WxPayException("企业付款API中，desc是必填参数！");
        }else if(!$inputObj->IsCheck_name()) {
            throw new WxPayException("企业付款API中，check_name是必填参数！");
        } else if(($inputObj->GetCheck_name() == "FORCE_CHECK") && !$inputObj->IsRe_user_nameSet()) {
            throw new WxPayException("企业付款API中，当check_name选项为FORCE_CHECK时，参数re_user_name为必填参数！");
        }


        $inputObj->SetAppid(\WxPay\Controller\IndexController::configs('appid'));//公众账号ID   \WxPayConfig::APPID
        $inputObj->SetMch_id(\WxPay\Controller\IndexController::configs('mchid'));//商户号       \WxPayConfig::MCHID
        $inputObj->SetNonce_str(self::getNonceStr());//随机字符串
		$inputObj->SetSpbill_create_ip($_SERVER['REMOTE_ADDR']);//终端ip	  

		$inputObj->SetSign();//签名
		$xml = $inputObj->ToXml();    
		
		//var_dump($xml);
		//die();

		$response = self::postXmlCurl($xml, $url, true, $timeOut);
		$result = \WxPayBusinessResults::Init($response);
		
		return $result;
    }

	/**
	 * 以post方式提交xml到对应的接口url
	 * 
	 * @param string $xml  需要post的xml数据
	 * @param string $url  url
	 * @param bool $useCert 是否需要证书，默认不需要
	 * @param int $second   url执行超时时间，默认30s
	 * @throws WxPayException
	 */
	private static function postXmlCurl($xml, $url, $useCert = false, $second = 30) {
		\Think\Log::write($xml);
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		
		//如果有配置代理这里就设置代理
		if(WxPayConfig::CURL_PROXY_HOST != "0.0.0.0" 
			&& WxPayConfig::CURL_PROXY_PORT != 0){
			curl_setopt($ch,CURLOPT_PROXY, WxPayConfig::CURL_PROXY_HOST);
			curl_setopt($ch,CURLOPT_PROXYPORT, WxPayConfig::CURL_PROXY_PORT);
		}
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);//严格校验
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	
		if($useCert == true){
			//设置证书
			//使用证书：cert 与 key 分别属于两个.pem文件
            curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLCERT, \WxPay\Controller\IndexController::configs('sslcert_path'));      //WxPayConfig::SSLCERT_PATH
            curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLKEY, \WxPay\Controller\IndexController::configs('sslkey_path'));        //WxPayConfig::SSLKEY_PATH
		}
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		//运行curl
		$data = curl_exec($ch);
		\Think\Log::write("postXmlCurl:".$data);
		//返回结果
		if($data){
			curl_close($ch);
			return $data;
		} else { 
			$error = curl_errno($ch);
			curl_close($ch);
			throw new \WxPayException("curl出错，错误码:$error");
		}
	}
	
	
    /**
	 * 
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	public static function getNonceStr($length = 32) {
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {  
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
		} 
		return $str;
	}
}

