<?php

vendor('WxpayAPI_php_v3.lib.WxPay#Data');
vendor('WxpayAPI_php_v3.lib.WxPay#Api');
vendor('WxpayAPI_php_v3.example.WxPay#JsApiPay');

require_once "WwWxPayUtils.php";

/**
 * 微往科技微信支付API(js版本), 因为js版本的支付，需要微信内核浏览器中提供的
 * 相关内置javascript对象
 *
 * @author: zhangyq <289525496@qq.com>
 * @date: 2016/05/14
 */
class WwWxPayJsApi {
    
    public function buildPackageInfo($openId, $notify_url, $WwWxOrderObject) {
        WwWxPayUtils::checkWxNotifyUrlFormat($notify_url);
        
        $input = new WxPayUnifiedOrder();

        $input->SetTime_start(date("YmdHis"));
        $input->SetTime_expire(date("YmdHis", time() + 600));
        //$input->SetSign();
        
        $input->SetBody($WwWxOrderObject->getDescription());
        $input->SetOut_trade_no($WwWxOrderObject->getOutTradeNo());
        //TOOD 充值金额不能为空
        $input->SetTotal_fee($WwWxOrderObject->getTotalFee()); // 以分为单位
        
        $input->SetNotify_url($notify_url);
        $input->SetSpbill_create_ip($_SERVER['REMOTE_ADDR']);
        $input->SetTrade_type("JSAPI");
        
        $input->SetOpenid($openId);

        //>>>>>>>>>>>>>>>>>>> WxPayUnifiedOrder对象设置结束 >>>>>>>>>>>>>>>>>>>>>>

        $WxPayApi = new WxPayApi();
        $wx_order = $WxPayApi->unifiedOrder($input);

        \Think\Log::write(print_r($wx_order, true));

        $tools = new JsApiPay();

        $jsApiParameters = $tools->GetJsApiParameters($wx_order);

        return $jsApiParameters;
    }

} 
