<?php

/**
 * 抽象微信订单为一个对象
 *
 * @author: zhangyq <289525496@qq.com>
 * @date: 2016.05.14
 */
class WwWxOrderObject {
    private $description;       //for SetBody
    private $outtradeno;        //for SetOutTradeNo
    private $totalfee;         //for SetTotalFee

    /**
     * 动态get,set方法对, 对属性的命名格式有要求，比如此例中，全部为小写
     *
     * @see 在PHP中，我们不能够直接通过方法名相同，签名不同的方法来实现方法重载，
     * 因为PHP是弱数据类型，不能很好的区分签名。但是，当调用一个类中并不存在的方
     * 法时，会自动调用__call()方法
     *
     * @link http://www.jb51.net/article/57484.htm
     */
    public function __call($method, $value) {
        $perfix=strtolower(substr($method,0,3));
        $property=strtolower(substr($method,3));
        
        if(empty($perfix)||empty($property))
            return;
        
        if($perfix=="get"&&isset($this->$property))
            return $this->$property;
        
        if($perfix=="set")
            $this->$property=$value[0];
    }
}
