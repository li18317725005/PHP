<?php

/**
 * 微信支付工具类集合
 *
 * @author: zhangyq <289525496@qq.com>
 * @date: 2016.05.14
 */

class WwWxPayUtils {

    /**
     * 比如thinkphp框架中，如果通过U方法或者其他URL获取方式，获得url格式如：
     * http://www.hnwwxxkj.com/index.php?=/Mobile/WxPay/notify
     * 会认为?后面的都是提交的参数
     *
     * 应该使用的url格式为: http://www.hnwwxxkj.com/index.php/Mobile/WxPay/notify
     */
    public static function checkWxNotifyUrlFormat($url) {
        if(!strstr($url, '?') || !strstr($url, '&')) 
            throw new Exception("微信不支持包含提交参数的回调URL格式");
    }
}
