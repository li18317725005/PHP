<?php

/**
 * 微信支付企业付款
 * 
 * @author 李海江
 */

namespace ThinkLib\Ext\Pay;

class CompanyPay {

    private $mchId = ''; //微信支付商户号 PartnerID 通过微信支付商户资料审核后邮件发送
    private $appId = ''; //微信支付申请对应的公众号的APPID
    private $appSecret = ''; //微信支付申请对应的公众号的APP Key
    private $key = ''; //https://pay.weixin.qq.com 帐户设置-安全设置-API安全-API密钥-设置API密钥
    private $orderNo; //订单号
    private $amount; //付款金额
    private $openid; //用户openid
    private $desc; //企业付款描述信息
    private $checkName; //校验用户姓名选项, NO_CHECK：不校验真实姓名, FORCE_CHECK：强校验真实姓名
    private $reUserName; //收款用户真实姓名。 如果check_name设置为FORCE_CHECK，则必填用户真实姓名

    public function __construct($orderNo, $amount, $openid, $desc, $checkName = 'NO_CHECK', $reUserName = '') {
        $this->orderNo = $orderNo;
        $this->amount = $amount;
        $this->openid = $openid;
        $this->desc = $desc;
        $this->checkName = $checkName;
        $this->reUserName = $reUserName;
    }

    public function pay() {
        if ($this->amount < 1) { //微信规定每次付款不得低于0.03元, 我们规定不得低于1元
            return ['code' => -99, 'msg' => '提现金额不能低于1元'];
        }
        $data['mch_appid'] = $this->appId;
        $data['mchid'] = $this->mchId;
        $data['nonce_str'] = '123'; //随机不长于32位的随机字符串
        $data['partner_trade_no'] = $this->orderNo;
        $data['openid'] = $this->openid;
        $data['amount'] = intval($this->amount * 100); //单位是分
        $data['desc'] = $this->desc;
        $data['spbill_create_ip'] = $this->getIp() ?: '118.190.82.52'; //Ip地址, 该IP同在商户平台设置的IP白名单中的IP没有关联，该IP可传用户端或者服务端的IP, 这里我传的是用户端ip
        $data['check_name'] = $this->checkName;
        \Think\Log::write('---------company_pay_data_00000000000000000---------------');
        \Think\Log::write(print_r($data, true));
        $this->checkName == 'FORCE_CHECK' ? $data['re_user_name'] = $this->reUserName : '';
        $data['sign'] = $this->getSign($data, $this->key);
        $responseXml = $this->postData('https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers', $this->ArrToXml($data));
        if (!$responseXml) {
            return ['code' => -100, 'msg' => '不能连接微信服务器'];
        }
        $response = simplexml_load_string($responseXml, 'SimpleXMLElement', LIBXML_NOCDATA);
        if (strval($response->return_code) != 'SUCCESS' || strval($response->result_code) != 'SUCCESS') {
            \Think\Log::write('---------company_pay_fail---------------');
            \Think\Log::write(print_r($this->orderNo, true));
            \Think\Log::write(print_r($this->openid, true));
            \Think\Log::write(print_r($response, true));
            return ['status' => -200, 'msg' => $response->return_msg . '：' . $response->err_code_des];
        }
        return ['code' => 200, 'msg' => '提现成功'];
    }

    //获取签名
    public function getSign($params, $key) {
        ksort($params, SORT_STRING);
        $unSignParaString = $this->formatQueryParaMap($params, false);
        $signStr = strtoupper(md5($unSignParaString . "&key=" . $key));
        return $signStr;
    }

    protected function formatQueryParaMap($paraMap, $urlEncode = false) {
        $buff = "";
        ksort($paraMap);
        foreach ($paraMap as $k => $v) {
            if (null != $v && "null" != $v) {
                if ($urlEncode) {
                    $v = urlencode($v);
                }
                $buff .= $k . "=" . $v . "&";
            }
        }
        $reqPar = '';
        if (strlen($buff) > 0) {
            $reqPar = substr($buff, 0, strlen($buff) - 1);
        }
        return $reqPar;
    }

    //数组转XML  
    function ArrToXml($arr) {
        if (!is_array($arr) || count($arr) == 0)
            return '';
        $xml = "<xml>";
        foreach ($arr as $key => $val) {
            if (is_numeric($val)) {
                $xml .= "<" . $key . ">" . $val . "</" . $key . ">";
            } else {
                $xml .= "<" . $key . "><![CDATA[" . $val . "]]></" . $key . ">";
            }
        }
        $xml .= "</xml>";
        return $xml;
    }

    /**
     * 生成随机字符串
     * @param type $length 生成长度
     * @param type $Big 是否包含大写字母
     * @param type $Num 是否包含数字
     * @param type $lower 是否包含小写字母
     * @param type $s 是否包含符号
     * @return type 生成的字符串
     */
    function getRandChar($length, $Big = true, $Num = true, $lower = true, $s = false) {
        $str = null;
        $strPol .= $Big ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : '';
        $strPol .= $Num ? "0123456789" : '';
        $strPol .= $lower ? "abcdefghijklmnopqrstuvwxyz" : '';
        $strPol .= $s ? "~!@#$%^&*()_+|<>?:;,.=-" : '';
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)]; //rand($min,$max)生成介于min和max两个数之间的一个随机整数
        }
        return $str;
    }

    //不同环境下获取客户端真实的IP
    public function getIp() {
        if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
            $ip = getenv('HTTP_CLIENT_IP');
        } elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
            $ip = getenv('HTTP_X_FORWARDED_FOR');
        } elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
            $ip = getenv('REMOTE_ADDR');
        } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        $res = preg_match('/[\d\.]{7,15}/', $ip, $matches) ? $matches [0] : '';
        return $res;
    }

    //发送数据  
    function postData($url, $postfields) {
        $ch = curl_init();
        $params[CURLOPT_URL] = $url;    //请求url地址  
        $params[CURLOPT_HEADER] = false; //是否返回响应头信息  
        $params[CURLOPT_RETURNTRANSFER] = true; //是否将结果返回  
        $params[CURLOPT_FOLLOWLOCATION] = true; //是否重定向  
        $params[CURLOPT_POST] = true;
        $params[CURLOPT_POSTFIELDS] = $postfields;
        $params[CURLOPT_SSL_VERIFYPEER] = false;
        $params[CURLOPT_SSL_VERIFYHOST] = false;
        //以下是证书相关代码  
        $params[CURLOPT_SSLCERTTYPE] = 'PEM';
        $params[CURLOPT_SSLCERT] = getcwd() . "/data/cert/apiclient_cert.pem"; //绝对路径  
        $params[CURLOPT_SSLKEYTYPE] = 'PEM';
        $params[CURLOPT_SSLKEY] = getcwd() . "/data/cert/apiclient_key.pem"; //绝对路径  
        curl_setopt_array($ch, $params); //传入curl参数  
        $content = curl_exec($ch); //执行  
        curl_close($ch); //关闭连接  
        return $content;
    }

}
