<?php
namespace Home\Controller;
use Think\Controller;
header("Content-Type:text/html; charset=utf-8");
class WplatSetController extends Controller{
    public function index(){
        $wp_uuid = I('get.wp_uuid');
        $info = D('wplatinfo') -> getInfo($wp_uuid);
        //获得参数 signature nonce token timestamp echostr
        $echoStr = $_GET["echostr"];
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
        $token = $info['wp_token'];
        //形成数组，然后按字典序排序
        $tmpArr = array($token, $timestamp, $nonce);
        sort($tmpArr, SORT_STRING);

        //拼接成字符串,sha1加密 ，然后与signature进行校验
        $tmpStr = implode($tmpArr);
        $tmpStr = sha1($tmpStr);
        if($tmpStr == $signature && $echoStr){
            //第一次接入weixin api接口的时候
            echo $echoStr;
            exit;
        }else {
            //第二次接入weixin api接口的时候
            $this->responseMsg($wp_uuid);
        }
    }

    public function responseMsg($wp_uuid){
        //1.获取到微信推送过来post数据（xml格式）
        $postStr = $GLOBALS["HTTP_RAW_POST_DATA"];
        if(!empty($postStr)){
            libxml_disable_entity_loader(true);
            $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
            if(strtolower($postObj->MsgType)=='text'){//关键字回复
                $where1['keyword'] = trim($postObj->Content);
                $where1['wp_uuid'] = $wp_uuid;
                $where1['event'] = 1;
                $reply = D('wplatset') -> getReply($where1);
                if(!$reply){//查找是否设置不匹配回复
                    $where2['wp_uuid'] = $wp_uuid;
                    $where2['event'] = 3;
                    $reply = D('wplatset') -> getReply($where2);
                    if(!$reply) return false;
                }
                $material = D('wplatset') -> getMaterial($reply['material_id']);//获取回复素材信息
                $this->response($material,$postObj);
            }elseif(strtolower($postObj->MsgType)=='event'){
                if(strtolower($postObj->Event)=='subscribe'){//关注回复
                    $where1['wp_uuid'] = $wp_uuid;
                    $where1['event'] = 2;
                    $subscribe = D('wplatset') -> getReply($where1);
                    if(!$subscribe) return false;
                    $material = D('wplatset') -> getMaterial($subscribe['material_id']);//获取回复素材信息
                    $this->response($material,$postObj);
                }elseif(strtolower($postObj->Event)=='click'){//菜单回复
                    $where1['wp_uuid'] = $wp_uuid;
                    $where1['keyword'] = trim($postObj->EventKey);
                    $reply = D('wplatset') -> getReply($where1);
                    if(!$reply){//查找是否设置不匹配回复
                        $where2['wp_uuid'] = $wp_uuid;
                        $where2['event'] = 3;
                        $reply = D('wplatset') -> getReply($where2);
                        if(!$reply) return false;
                    }
                    $material = D('wplatset') -> getMaterial($reply['material_id']);//获取回复素材信息
                    $this->response($material,$postObj);
                }
            }
        }else {
            echo "";
            exit;
        }
    }

    //回复素材表中获取
    private function response($material,$postObj)
    {
        switch ($material['type']) {
            case 'text'://回复文本
                echo D('wplatset')->responseText($postObj, $material['content']);
                break;
            case 'img'://回复图片
                echo D('wplatset')->responseImage($postObj, $material['media_id']);
                break;
            case 'voice'://回复语音
                echo D('wplatset')->responseVoice($postObj, $material['media_id'], $material['title']);
                break;
            case 'news'://回复图文
                $data = array(
                    array(
                        'title' => $material['title'],
                        'description' => $material['content'],
                        'picUrl' => $material['picurl'],
                        'url' => $material['url'],
                    ),
                );
                echo D('wplatset')->responseNews($postObj, $data);
                break;
            case 'newss':
                $data = array(
                    array(
                        'title' => $material['title'],
                        'description' => $material['content'],
                        'picUrl' => $material['picurl'],
                        'url' => $material['url'],
                    ),
                );
                $news = D('wplatset') -> getNews($material['id']);//查找子图文
                foreach($news as $v){
                    array_push($data,array(
                        'title' => $v['title'],
                        'description' => $v['content'],
                        'picUrl' => $v['picurl'],
                        'url' => $v['url'],
                    ));
                }
                echo D('wplatset')->responseNews($postObj, $data);
                break;
            case 'video':
                echo D('wplatset')->responseVideo($postObj,  $material['media_id'], $material['title'], $material['content']);
                break;
        }
    }
}