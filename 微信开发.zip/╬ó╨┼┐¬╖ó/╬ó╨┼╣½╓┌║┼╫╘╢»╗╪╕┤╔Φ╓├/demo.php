<?php
//更新自定义菜单
function updateMenu()
{
    if (I('get.product_home_url') && I('get.product_name')) {
        //产品选择设置自定义菜单产品链接
        $data['name'] = I('get.product_name');
        $data['method'] = 1;
        $data['url'] = I('get.product_home_url');
        $_POST['menu'] = array(array($data));
    }
    $session = new \Org\Util\Session();
    $wp_uuid = $session->getWplatUuid();
    $error = true;
    foreach ($_POST['menu'] as $k => $v) {//确认每个一级菜单下二级菜单的数量
        if (count($v) > 6) $error = false;
    }
    if (count($_POST['menu']) < 4 && $error) {//确认一级菜单的数量
        $Wpmenu = D('Wpmenu');
        $Wplatinfo = D('Wplatinfo');
        $del = $Wpmenu->delInfo($wp_uuid);//更新之前删除原有的自定义菜单
        if (!$del) return $this->error("发布失败");
        foreach ($_POST['menu'] as $k => $v) {
            $v[0]['wp_uuid'] = $wp_uuid;
            $p_id = $Wpmenu->addInfo($v[0]);//一级菜单信息入库，一级菜单id为二级菜单的父id
            $arr[$k]['name'] = urlencode($v[0]['name']);
            if (count($v) == 1) {//判断是否有二级菜单
                switch ($v[0]['method']) {//判断一级菜单的type
                    case 1:
                        $arr[$k]['type'] = 'view';
                        $arr[$k]['url'] = $v[0]['url'];
                        break;
                    case 2:
                        $arr[$k]['type'] = 'click';
                        $arr[$k]['key'] = urlencode($v[0]['keyword']);
                        break;
                }
            }
            foreach ($v as $k1 => $v1) {//二级菜单信息入库
                if (!$k1) continue;//去除第一个一级菜单元素
                $v1['p_id'] = $p_id;
                $v1['wp_uuid'] = $wp_uuid;
                $Wpmenu->addInfo($v1);
                $arr[$k]['sub_button'][$k1]['name'] = urlencode($v1['name']);
                switch ($v1['method']) {//判断二级菜单的type
                    case 1:
                        $arr[$k]['sub_button'][$k1]['type'] = 'view';
                        $arr[$k]['sub_button'][$k1]['url'] = $v1['url'];
                        break;
                    case 2:
                        $arr[$k]['sub_button'][$k1]['type'] = 'click';
                        $arr[$k]['sub_button'][$k1]['key'] = urlencode($v1['keyword']);
                        break;
                }
            }
            $arr[$k]['sub_button'] = array_values($arr[$k]['sub_button']);//微信需要的json为索引数组
        }
        $arr = array_values($arr);//微信需要的json为索引数组
        $menu['button'] = $arr;
        //获取appid和appsecret
        $info = $Wplatinfo->getInfo($wp_uuid);
        $wx = new Weixin($info['wp_appid'], $info['wp_appsecret']);
        $res = json_decode($wx->create_menu($menu), true);//创建自定义菜单
        if ($res['errcode'] == 0) {
            $this->success("发布成功", U("AccountMember/menu?wp_uuid=$wp_uuid"), 2);
        } else {
            $this->error("发布失败,请确认输入信息是否正确！", U("AccountMember/menu"), 2);
        }
    } else {
        $this->error("最多只能发布三个一级菜单，并且每个一级菜单下最多有五个二级菜单");
    }
}