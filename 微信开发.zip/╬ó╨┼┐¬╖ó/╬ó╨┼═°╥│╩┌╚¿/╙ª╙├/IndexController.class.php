<?php

namespace Dbf\Controller;

use Dbf\Controller\BaseController;

class IndexController extends BaseController {

    public function _initialize() {
        //判断是否是微信浏览器
        if (is_weixin() && empty($_SESSION['USER_ID'])) {
            $callBackUrl = urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
            $this->authorize(C('WX_AUTHORIZE_URL') . '?call_back=' . $callBackUrl, $_GET['code']);
        }
    }

    //端午节活动页面
    public function index() {
        P($_SESSION);
        $this->display();
    }

}
