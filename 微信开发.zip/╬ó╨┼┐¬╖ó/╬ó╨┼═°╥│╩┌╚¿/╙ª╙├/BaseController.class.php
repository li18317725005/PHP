<?php

namespace Dbf\Controller;

use Think\Controller;

class BaseController extends Controller {

    public function authorize($url, $code = '') {
        $authSvc = new \Common\Service\Authorize();
        $authSvc->index($url, $code);
    }

}
