<?php

/**
 * 微信网页授权跳转页面(在微信后台设置的网页授权回调地址域名下)
 * @author 李海江
 */

namespace Home\Controller;

class WxAuthorizeController {
    /**
     * 获取code, 该方法是其他项目的微信授权回调地址
     */
    public function getCode() {
        $url = urldecode($_GET['call_back']) . '?code=' . $_GET['code'];
        header('location:' . $url);
    }

}
