<?php

/**
 * 公共publicMD
 */

namespace Common\Model;

use Think\Model;

class PublicMD extends Model {

    /**
     * 增
     * @param type $data
     * @return boolean
     */
    public function add_data($data = array()) {
        if (empty($data)) {
            return FALSE;
        }
        return $this->add($data);
    }

    /**
     * 批量插入数据
     * @param type $data
     * @return boolean
     */
    public function add_all_data($data = array()) {
        if (empty($data)) {
            return false;
        }
        return $this->addAll($data);
    }

    /**
     * 删
     * @param type $where
     * @return boolean
     */
    public function delete_where($where = '') {
        if (empty($where)) {
            return FALSE;
        }
        return $this->where($where)->delete();
    }

    public function save_data($data = array()) {
        return $this->save_where_data($data);
    }

    /**
     * 改
     * @param type $data 传入数据
     * @param type $where 传入条件
     * @return boolean 影响的行数
     */
    public function save_where_data($data = array(), $where = '') {
        if (empty($data)) {
            return FALSE;
        }
        if (empty($where)) {
            return $this->save($data);
        } else {
            return $this->where($where)->save($data);
        }
    }

    ///////////////////////////////////////////////查///////////////////////////////////////////////
    /**
     * 根据条件查询1条数据find()，条件为空返回第一条数据
     * @param type $where
     * @return type
     */
    public function find_admin_where_data($where = '') {
        if ($where == '') {
            return false;
        } else {
            return $this->find_where_data($where);
        }
    }

    /**
     * 根据条件查询1条数据find()，条件为空返回第一条数据
     * @param type $where
     * @return type
     */
    public function find_where_data($where = '') {
        if ($where == '') {
            return $this->find();
        } else {
            return $this->where($where)->find();
        }
    }

    /**
     * where数据通过order排序
     * @param type $orderby
     * @return type
     */
    public function find_where_orderby_data($where = 'id>0', $orderby = 'id') {
        return $this->where($where)->order($orderby)->find();
    }

    /////////////////////////////////count/////////////////////////////////
    /**
     * 满足指定条件的数据数量
     * @param type $where
     * @return type
     */
    public function get_where_data_count($where = 'id>0') {
        return $this->where($where)->count();
    }

    /**
     * 数据表内所有数据数量
     * @return type
     */
    public function get_all_data_count() {
        return $this->count();
    }

    /////////////////////////////////select/////////////////////////////////    

    /**
     * 指定条件指定字段select
     * @param type $where 条件
     * @param type $order 排序
     * @param type $field 字段
     * @return type 数据集
     */
    public function selectWhereField($where = array(), $order = '', $field = '*') {
        return $this->field($field)->where($where)->order($order)->select();
    }

    /**
     * 根据条件进行查询，条件为空查询全部
     * @param type $where
     * @return type
     */
    public function select_where_data($where = '') {
        if ($where == '') {
            return $this->select();
        } else {
            return $this->where($where)->select();
        }
    }

    /**
     * 返回全部数据的limit数据
     * @param type $offset
     * @param type $length
     * @return type
     */
    public function select_limit_data($offset = 0, $length = 10) {
        return $this->limit($offset, $length)->select();
    }

    /**
     * 返回指定条件的limit数据
     * @param type $offset
     * @param type $length
     * @return type
     */
    public function select_where_limit_data($where = 'id>0', $limit = 0, $offset = 10) {
        return $this->where($where)->limit($limit, $offset)->select();
    }

    /**
     * 全部数据，通过order排序
     * @param type $orderby
     * @return type
     */
    public function select_all_orderby_data($orderby = 'id') {
        return $this->order($orderby)->select();
    }

    /**
     * where数据通过order排序
     * @param type $orderby
     * @return type
     */
    public function select_where_orderby_data($where = 'id>0', $orderby = 'id') {
        return $this->where($where)->order($orderby)->select();
    }

    /**
     * where数据通过order排序
     * @param type $orderby
     * @return type
     */
    public function select_where_limit_orderby_data($where = 'id>0', $orderby = 'id', $limit = 0, $offset = 10) {
        return $this->where($where)->order($orderby)->limit($limit, $offset)->select();
    }

    /**
     * 
     * @param type $where
     * @param type $field
     * @param type $orderby
     * @param type $limit
     * @param type $offset
     * @return type
     */
    public function select_field_where_limit_orderby_data($where = 'id>0', $field = '*', $orderby = 'id', $limit = 0, $offset = 10) {
        return $this->field($field)->where($where)->order($orderby)->limit($limit, $offset)->select();
    }

    /**
     * where数据通过order排序
     * @param type $orderby
     * @return type
     */
    public function select_limit_orderby_data($orderby = 'id', $offset = 0, $length = 10) {
        return $this->order($orderby)->limit($offset, $length)->select();
    }

    /////////////////////////////////all/////////////////////////////////
    /**
     * 返回全部数据
     * @return type
     */
    public function get_all_data() {
        return $this->select();
    }

    /////////////////////////////////构造统计数据/////////////////////////////////
    function get_tongji_db($where, $field1, $field2) {
        $rnt_data = '';
        $engine0 = $this->field($field1)->where($where)->group('d1')->order('d1 ASC')->select();
        foreach ($engine0 as $k => $value) {
            $rnt_data .= "'" . $value[d1] . "'" . ",";
        }
        $rnt_data = substr($rnt_data, 0, -1) . "#";
        $engine = $this->field($field2)->where($where)->group('d1')->order('d1 ASC')->select();
        foreach ($engine as $k => $value) {
            $rnt_data .= $value[d2] . ",";
        }
        return substr($rnt_data, 0, -1);
    }

    //-------------------------------------------------------------------------------------------------------------
    /**
     * 新增数据
     */
    public function addData($data) {
        return $this->add($data);
    }

    /**
     * 批量新增
     */
    public function addDataAll($data) {
        return $this->addAll($data);
    }

    /**
     * 删除数据
     */
    public function delData($id) {
        return $this->where(array('id' => $id))->delete();
    }

    public function delDataByCondition($where) {
        return $this->where($where)->delete();
    }

    /**
     * 修改数据
     */
    public function saveData($id, $data) {
        return $this->where(array('id' => $id))->save($data);
    }

    public function saveDataByCondition($where, $data) {
        return $this->where($where)->save($data);
    }

    /**
     * 获取数据
     */
    public function getInfo($id, $filed = '*') {
        return $this->field($filed)->where(array('id' => $id))->find();
    }

    public function getInfoByCondition($where, $filed = '*', $order = '') {
        return $this->field($filed)->where($where)->order($order)->find();
    }

    public function getFields($where, $field) {
        return $this->where($where)->getField($field);
    }

    /**
     * 获取列表
     */
    public function getDataList($where = array(), $field = '*', $offset = 0, $pageSize = 10, $order = 'id desc') {
        return $this->field($field)->where($where)->order($order)->limit($offset, $pageSize)->select();
    }

    /**
     * 获取总数
     */
    public function getCount($where = array()) {
        return $this->where($where)->count();
    }

    /**
     * 增/删某字段
     */
    public function setFieldInc($where, $field, $step = 1) {
        return $this->where($where)->setInc($field, $step);
    }

    public function setFieldDec($where, $field, $step = 1) {
        return $this->where($where)->setDec($field, $step);
    }

    /*
     * 批量更新
     * @ $table_name 表名全名
     * @ data 更新的数据 二维数组
     * @ $field 主键
     * @ 返回执行行数
     */

    function batch_update($table_name = '', $data = array(), $field = '') {
        if (!$table_name || !$data || !$field) {
            return false;
        } else {
            $sql = 'UPDATE ' . $table_name;
        }
        $con = array();
        $con_sql = array();
        $fields = array();
        foreach ($data as $key => $value) {
            $x = 0;
            foreach ($value as $k => $v) {
                if ($k != $field && !$con[$x] && $x == 0) {
                    $con[$x] = " set {$k} = (CASE {$field} ";
                } elseif ($k != $field && !$con[$x] && $x > 0) {
                    $con[$x] = " {$k} = (CASE {$field} ";
                }
                if ($k != $field) {
                    $temp = $value[$field];
                    $con_sql[$x] .= " WHEN '{$temp}' THEN '{$v}' ";
                    $x++;
                }
            }
            $temp = $value[$field];

            if (!in_array($temp, $fields)) {
                $fields[] = $temp;
            }
        }
        $num = count($con) - 1;
        foreach ($con as $key => $value) {

            foreach ($con_sql as $k => $v) {

                if ($k == $key && $key < $num) {
                    $sql .= $value . $v . ' end),';
                } elseif ($k == $key && $key == $num) {
                    $sql .= $value . $v . ' end)';
                }
            }
        }
        $str = implode(',', $fields);
        $sql .= " where {$field} in({$str})";
        $res = M()->execute($sql);
        return $res;
    }

}
