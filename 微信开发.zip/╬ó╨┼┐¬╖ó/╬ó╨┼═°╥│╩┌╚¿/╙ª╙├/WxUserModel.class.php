<?php
/**
 * 微信用户表
 */
namespace Common\Model;

use Common\Model\PublicMD;

class WxUserModel extends PublicMD {
    
}

