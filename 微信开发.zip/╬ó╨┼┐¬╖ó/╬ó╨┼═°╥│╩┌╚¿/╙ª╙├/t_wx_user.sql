/*
Navicat MySQL Data Transfer

Source Server         : 线上3号
Source Server Version : 50635
Source Host           : 47.104.4.75:3306
Source Database       : Action

Target Server Type    : MYSQL
Target Server Version : 50635
File Encoding         : 65001

Date: 2018-06-11 18:15:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for qj_wx_user
-- ----------------------------
DROP TABLE IF EXISTS `qj_wx_user`;
CREATE TABLE `qj_wx_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) NOT NULL DEFAULT '' COMMENT '微信昵称',
  `headimgurl` varchar(255) NOT NULL DEFAULT '' COMMENT '微信头像',
  `openid` varchar(60) NOT NULL DEFAULT '' COMMENT '用户在公众号里的唯一标识',
  `unionid` varchar(60) NOT NULL DEFAULT '' COMMENT '用户在微信的原始标识',
  `country` varchar(30) NOT NULL DEFAULT '' COMMENT '国家',
  `sex` tinyint(3) NOT NULL DEFAULT '1' COMMENT '1男 2女',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flag` (`openid`,`unionid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
