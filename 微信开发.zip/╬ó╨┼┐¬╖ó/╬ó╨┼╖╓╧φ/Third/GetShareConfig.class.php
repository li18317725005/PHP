<?php

/**
 * 微信分享
 * User: 海江
 * Date: 2017/3/14
 * Time: 14:58
 */

namespace Third;

class GetShareConfig {
    
    private $appid = 'wx9f74c1a1961dcb26';
    private $secret = '7c7da5c4694fe7bec65f07b02a1d2b06';

    /**
     * 此分享功能只能在微信内打开进行分享
     */
    public function shareConfig() {
        $timestamp = time();
        $wxnonceStr = $this->getRandChar(16);
        $wxticket = $this->wxGetJsapiTicket();
        $curr_url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s", $wxticket, $wxnonceStr, $timestamp, $curr_url);
        $wxSha1 = sha1($wxOri);
        $data['timestamp'] = $timestamp;
        $data['nonceStr'] = $wxnonceStr;
        $data['wxticket'] = $wxticket;
        $data['signature'] = $wxSha1;
        $data['appid'] = $this->appid;
        return $data;
    }

    function wxGetJsapiTicket() {
        $ticket = "";
        do {
            $ticket = S('wx_ticket');
            if (!empty($ticket)) {
                break;
            }
            $token = S('access_token');
            if (empty($token)) {
                $token = $this->wxGetToken();
            }
            $url2 = sprintf("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=jsapi", $token);
            $res = file_get_contents($url2);
            $res = json_decode($res, true);
            $ticket = $res['ticket'];
            // 注意：这里需要将获取到的ticket缓存起来（或写到数据库中）
            // ticket和token一样，不能频繁的访问接口来获取，在每次获取后，我们把它保存起来。
            S('wx_ticket', $ticket, 3600);
        } while (0);
        return $ticket;
    }

    function wxGetToken() {
        $token = S('access_token');
        if (!$token) {
            //此处的appid配置信息可以从数据库中获取，或者根据需求进行架构进行修改
            $appid = $this->appid;
            $secret = $this->secret;
            $res = file_get_contents('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $secret);
            $res = json_decode($res, true);
            $token = $res['access_token'];
            S('access_token', $token, 3600);
        }
        return $token;
    }

    /**
     * 生成随机字符串
     * @param type $length 生成长度
     * @param type $Big 是否包含大写字母
     * @param type $Num 是否包含数字
     * @param type $lower 是否包含小写字母
     * @param type $s 是否包含符号
     * @return type 生成的字符串
     */
    function getRandChar($length, $Big = true, $Num = true, $lower = true, $s = false) {
        $str = null;
        $strPol .= $Big ? "ABCDEFGHIJKLMNOPQRSTUVWXYZ" : '';
        $strPol .= $Num ? "0123456789" : '';
        $strPol .= $lower ? "abcdefghijklmnopqrstuvwxyz" : '';
        $strPol .= $s ? "~!@#$%^&*()_+|<>?:;,.=-" : '';
        $max = strlen($strPol) - 1;
        for ($i = 0; $i < $length; $i++) {
            $str .= $strPol[rand(0, $max)]; //rand($min,$max)生成介于min和max两个数之间的一个随机整数
        }
        return $str;
    }

}
