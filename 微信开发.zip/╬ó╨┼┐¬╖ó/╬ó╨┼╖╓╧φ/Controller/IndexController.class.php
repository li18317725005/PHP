<?php

namespace Home\Controller;

use Think\Controller;
use Third\GetShareConfig;

class IndexController extends Controller {

    private $wxShare;

    public function _initialize() {
        $this->wxShare = new GetShareConfig();
    }

    //页面
    public function index() {
        //微信分享内容
        $shareConfig = $this->wxShare->shareConfig();
        $shareContent['title'] = '六一儿童节快乐';
        $shareContent['desc'] = '来自全景智慧城市的分享-六一儿童节快乐';
        $shareContent['link'] = 'http://action.360vrsh.com/home/index/index';
        $shareContent['type'] = 'link';   //分享类型   music video   link   默认：link
        $shareContent['dataUrl'] = "";    // 如果type是music或video，则要提供数据链接，默认为空
        $shareContent['img'] = 'http://action.360vrsh.com/Public/images/share.jpg';
        $this->assign('wxconfig',$shareConfig);
        $this->assign('wxShare',$shareContent);
        $this->display();
    }

}
