<?php
return array(
    "NAME" => '分类名称',
    "CATEGORY_TYPE" => '分类类型',
    "CATEGORY_URL" => '访问',
    "ADD_SUB_CATEGORY" => '添加子类',
    "CATEGORY_DESCRIPTION" => '描述',
    "PARENT" => '上级',
    "ROOT" => '作为一级分类',
    "SEO_TITLE" => 'SEO标题',
    "SEO_KEYWORDS" => 'SEO关键字',
    "SEO_DESCRIPTION" => 'SEO描述',
    "LIST_TEMPLATE" => '列表页模板',
    "ARTICLE_TEMPLATE" => '单文章模板',
    "GENERAL_SETTING" => '基本属性',
    "SEO_SETTING" => 'SEO设置',
    "TEMPLATE_SETTING" => '模板设置'
);