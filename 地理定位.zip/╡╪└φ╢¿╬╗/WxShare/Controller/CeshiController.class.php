<?php
/**
 * 分享测试版
 * User: xiafan
 * Date: 2017/3/14
 * Time: 14:58
 */
namespace WxShare\Controller;

use Common\Controller\HomebaseController;
use Think\Controller;

class CeshiController extends HomebaseController{

    public function index(){
        $share = new WxShareController();
        $share_config = $share->share_config();
        $share_content['title'] = "Ceshi"; //分享标题
        $share_content['desc'] = "微信分享测试";   //分享描述
        $share_content['link'] = "http://www.hnwwxxkj.com";  //分享的链接
        $share_content['type'] = 'link';   //分享类型   music video   link   默认：link
        $share_content['dataUrl'] = "";    // 如果type是music或video，则要提供数据链接，默认为空
        $share_content['imgUrl'] = "http://pic71.nipic.com/file/20150629/17961491_211658772000_2.jpg";    //分享图标

        $this->assign('share_config',$share_config);
        $this->assign('share_content',$share_content);
        $this->display();
    }

}