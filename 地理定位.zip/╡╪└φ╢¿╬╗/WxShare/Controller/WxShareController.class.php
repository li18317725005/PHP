<?php
/**
 * 微信分享
 * User: xiafan
 * Date: 2017/3/14
 * Time: 14:58
 */
namespace WxShare\Controller;

use Think\Controller;

class WxShareController extends Controller{
    /**
     * 此分享功能只能在微信内打开进行分享
     */
    public function share_config(){
        $timestamp = time();
        $wxnonceStr = "5414102365874102";
        $wxticket = $this->wx_get_jsapi_ticket();
        $curr_url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
       // $share_url = 'http://www.baidu.com';
        $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s",$wxticket, $wxnonceStr, $timestamp, $curr_url);
        $wxSha1 = sha1($wxOri);
        $data['timestamp']=$timestamp;
        $data['nonceStr']=$wxnonceStr;
        $data['wxticket']=$wxticket;
        $data['signature']=$wxSha1;
        $data['appid'] = 'wx87d6f46cbcb4e1c8';
       // $data['share_url'] = $share_url;
        return $data;

    }

    function wx_get_token(){
        $token = S('access_token');
        if (!$token) {
            //此处的appid配置信息可以从数据库中获取，或者根据需求进行架构进行修改
            $appid = 'wx87d6f46cbcb4e1c8';
            $secret = '0f7ee61ea1fdd990503e2fa5794bcfc7';
            $res = file_get_contents('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appid.'&secret='.$secret);
            $res = json_decode($res, true);
            $token = $res['access_token'];
            S('access_token', $token, 3600);
        }
        return $token;
    }


    function wx_get_jsapi_ticket(){
        $ticket = "";
        do{
            $ticket = S('wx_ticket');
            if (!empty($ticket)) {
                break;
            }
            $token = S('access_token');
            if (empty($token)){
                $token = $this->wx_get_token();
            }
            $url2 = sprintf("https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=jsapi",
                $token);
            $res = file_get_contents($url2);
            $res = json_decode($res, true);
            $ticket = $res['ticket'];
            // 注意：这里需要将获取到的ticket缓存起来（或写到数据库中）
            // ticket和token一样，不能频繁的访问接口来获取，在每次获取后，我们把它保存起来。
            S('wx_ticket', $ticket, 3600);
        }while(0);
        return $ticket;
    }




}