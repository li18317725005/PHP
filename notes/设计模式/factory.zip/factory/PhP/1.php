<?php
header('Content-Type:text/html;charset=utf-8');
//简单工厂模式（静态工厂方法模式）
//简单工厂模式又称静态工厂方法模式，之所以可以这么说，是因为简单工厂模式是通过一个静态方法来创建对象的。

// Interface people 创建人类
interface  people{
    public function  say();
}

//Class man 继承people的男人类，设置人类的性别
class man implements people{
    // 具体实现people的say方法
    public function say(){
        echo '我是男人<br>';
    }
}

//Class woman 继承people的女人类，设置人类的性别
class women implements people{
    // 具体实现people的say方法
    public function say(){
        echo '我是女人<br>';
    }
}

//Class SimpleFactoty 工厂类，创建简单工厂。
class SimpleFactoty{
    // 简单工厂里的静态方法-用于创建男人对象
    static function createMan(){
        return new man();
    }
	// 简单工厂里的静态方法-用于创建女人对象
    static function createWomen(){
        return new women();
    }
}

//具体调用
//男人的调用
$man = SimpleFactoty::createMan();
$man->say();
//运行结果：我是男人

//女人的调用
$woman = SimpleFactoty::createWomen();
$woman->say();
//运行结果：我是女人
