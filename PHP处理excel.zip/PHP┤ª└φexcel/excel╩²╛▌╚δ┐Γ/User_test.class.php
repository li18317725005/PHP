<?php
namespace Common\Common;

class User_test extends Base {
	protected $name;
	protected $sex;

	public function __construct($name,
								$sex
								) {
		$this->name = $name;
		$this->sex = $sex;
	}
}