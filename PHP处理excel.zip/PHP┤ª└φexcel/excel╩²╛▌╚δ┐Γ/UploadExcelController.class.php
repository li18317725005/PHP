<?php
/**
 * 上传excel控制器
 */
namespace Home\Controller;

use Common\Controller\HomebaseController;
use Home\Common\ReadExcel;

class UploadExcelController extends HomebaseController {
	private $rootPath = './data/upload/Excel/';
	private $exts = array('xls', 'xlsx', 'xlsm', 'xltx', 'xltm', 'xlsb', 'xlam');

	public function index() {
		if ($_FILES) {
			$info = uploadOne($_FILES['excel'], $this->rootPath, $this->exts);
			if (!is_array($info)) {
				$this->assign('excelError', $info);
			}else{
				//将上传的excel存入数据库
				$path = './data/upload/Excel/' . $info['savepath'] . $info['savename'];
				$result = ReadExcel::getObj($path)->getExcelContent();
				if ($result) {
					$this->success('导入成功', U('index'));
				} else {
					$this->error('上传失败');
				}
				die();
			}
		}
		$this->display();
	}
}