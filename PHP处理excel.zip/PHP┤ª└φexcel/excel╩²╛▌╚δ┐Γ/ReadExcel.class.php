<?php
namespace Home\Common;

use Home\Model\Factory;
vendor('PHPExcel');
vendor('PHPExcel.PHPExcel.IOFactory');

class ReadExcel {
	private static $obj = null;
	private $path;
	private $excelObj;

    /**
     * 构造方法
     * ReadExcel constructor.
     * @param $path excel文件的路径, 可以是项目根路径
     */
	private function __construct($path) {
		$this->path = $path;
	}

    /**
     * 单例模式
     * @param $path
     * @return ReadExcel|null
     */
	public static function getObj($path) {
		if (self::$obj instanceof self) {
			return self::$obj;
		}
		self::$obj = new self($path);
		return self::$obj;
	}

    /**
     * 获取excel的值并插入数据库
     * @return bool
     */
	public function getExcelContent() {
		//打开excel文件sheet1
		$this->excelObj = \PHPExcel_IOFactory::load($this->path);
		$this->excelObj->setActiveSheetIndex(0);
		$sheet0 = $this->excelObj->getSheet(0);
		//获取行数,循环读取
		$rowCount = $sheet0->getHighestRow();//excel行数 2
		$lastColumn = $sheet0->getHighestColumn();//最后一列 "B"
		$flag = true;
		for ($i = 2; $i <= $rowCount; $i++){
			$obj = new \Common\Common\User_test(
				$this->getExcelValue('A'.$i),
                ($this->getExcelValue('B'.$i) == '男') ? 1 : 2
			);
			$result = Factory::getModel('user_test')->addData($obj);
			if (!$result) $flag = false;
		}
		return $flag;
	}

    /**
     * 获取excel每一行对应列的值
     * @param 列
     * @param 行数
     * @return string
     */
	private function getExcelValue($column, $i) {
		return $this->excelObj->getActiveSheet()->getCell($column.$i)->getValue();
	}
}