<?php
/**
 * 导出excel控制器
 * @author 李海江 <18317725005@126.com>
 */
namespace Home\Controller;

use Common\Controller\HomebaseController;

class ExportExcelController extends HomebaseController {
    /**
     * 导出excel
     */
    public function index() {
        $this->display();
    }

    /**
     * 导出动作
     */
    public function export() {
        $where = array();
        $userList = M('user_test')->where($where)->select(); //用户列表
        $xlsName  = "用户信息表"; //文件名
        //表头名称
        $xlsCell  = array(
            array('key','编号'),
            array('name','用户名'),
            array('sex','性别'),
        );
        //去除无用的字段
        foreach ($userList as $k => $v) {
            $data[$k]['key'] = $k+1;
            $data[$k]['name'] = $v['name'];
            $data[$k]['sex'] = ($v['sex'] == '男' ? 1 : 2);
            $data[$k]['add_time'] = $v['add_time'];
        }
        exportExcel($xlsName ,$xlsCell ,$data);
    }
}