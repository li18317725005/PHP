<?php
/**
 * 格式化数据
 */
function P($data){
	echo "<pre>";
	print_r($data);
	echo "</pre>";
}

/**
 * 打印数据格式
 */
function V($data){
	echo "<pre>";
	var_dump($data);
	echo "</pre>";
}

/**
 * 分页
 * @param  int  $total      总记录数
 * @param  int  $listRows   每页显示记录数
 * @param  string  $params  参数
 * @return [type]           [description]
 */
function getPage($total, $pageSize, $params){
	$page = new \Think\Pages($total, $pageSize, $params);
	$pageArr['pageStr'] = $page->fpage(array(2, 3, 4, 6, 7));
	$pageArr['offset']  = $page->offset;
	return $pageArr;
}

/**
 * 生成uuid（唯一标识）
 * @return string
 */
function get_uuid(){
	if (function_exists('com_create_guid')){
		return com_create_guid();
	}else{
		mt_srand((double)microtime()*10000);
		$charid = strtoupper(md5(uniqid(rand(), true)));
		$hyphen = chr(45);// "-"
		$uuid = substr($charid, 0, 8).$hyphen
		.substr($charid, 8, 4).$hyphen
		.substr($charid,12, 4).$hyphen
		.substr($charid,16, 4).$hyphen
		.substr($charid,20,12);
		return $uuid;
	}
}

/**
 * 多文件文件上传
 * @param  [type] $rootPath [description]
 * @param  [type] $savePath [description]
 * @return [type]           [description]
 */
function uploadImg($rootPath, $savePath){
	$upload = new \Think\Upload();// 实例化上传类 
	$upload->maxSize = 3145728 ;// 设置附件上传大小 
	$upload->exts  =  array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型 
	$upload->rootPath = $rootPath; // 设置附件上传根目录 
	$upload->savePath = $savePath; // 设置附件上传（子）目录 // 上传文件  
	$info = $upload->upload();
	if (!$info){
		$info = $upload->getError();
	}
	return $info;
}

/**
 * 单个文件上传
 * @param  [type] $rootPath [description]
 * @param  [type] $savePath [description]
 * @return [type]           [description]
 */
function uploadImgOne($file, $rootPath, $savePath, $saveName=""){
	$upload = new \Think\Upload();// 实例化上传类 
	$upload->maxSize = 3145728 ;// 设置附件上传大小 
	$upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型 
	$upload->rootPath = $rootPath; // 设置附件上传根目录 
	$upload->savePath = $savePath; // 设置附件上传（子）目录 // 上传文件
	$upload->saveName = $saveName;
	// $upload->replace  = true;
	$info = $upload->uploadOne($file);
	if (!$info){
		$info = $upload->getError();
	}
	return $info;
}


/**
 * 字符串长度限定
 * @param  [type] $text   [description]
 * @param  [type] $length [description]
 * @return [type]         [description]
 */
function subtext($text, $length){
    if(mb_strlen($text, 'utf8') > $length) 
    return mb_substr($text, 0, $length, 'utf8').'...';
    return $text;
}


/**
 * curl请求接口
 * @param $url 请求网址
 * @param array $params 请求参数
 * @param int $ispost 请求方式 0 get 方式  1 post 方式
 * @param int $https https协议 0 http 协议 1 https 协议
 * @return bool|mixed
 */
function curl($url, $params = false, $ispost = 0, $https = 0)
{
	$httpInfo = array();
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	if ($https) {
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // 对认证证书来源的检查
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); // 从证书中检查SSL加密算法是否存在
	}
	if ($ispost) {
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
		curl_setopt($ch, CURLOPT_URL, $url);
	} else {

		if ($params) {
			if (is_array($params)) {
				$params = http_build_query($params);
			}
			curl_setopt($ch, CURLOPT_URL, $url . '?' . $params);
		} else {
			curl_setopt($ch, CURLOPT_URL, $url);
		}
	}
	$response = curl_exec($ch);
	if ($response === FALSE) {
		//echo "cURL Error: " . curl_error($ch);
		return false;
	}
	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	$httpInfo = array_merge($httpInfo, curl_getinfo($ch));
	curl_close($ch);
	return $response;
}

/**
 * $expTitle  文件名称 
 * $expCellName  列名称 二维 数组 
 * $expTableData 列数据 二维
 */
function exportExcel($expTitle,$expCellName,$expTableData){
    ob_clean();
    $xlsTitle = iconv('utf-8', 'gb2312', $expTitle);//文件名称
    $fileName = $expTitle.'_'.date('YmdHis',time()).rand(100000,999999);//or $xlsTitle 文件名称可根据自己情况设定
    $cellNum = count($expCellName);// 有几列
    $dataNum = count($expTableData);// 有几行数据
	vendor('PHPExcel.PHPExcel','','.php');
	vendor('PHPExcel.PHPExcel.IOFactory','','.php');
	// 一定要加根 命名空间   \
    $objPHPExcel = new \PHPExcel();
    $cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
    //将第一行合并单元格
    $objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');
   // $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'  Export time:'.date('Y-m-d H:i:s'));  
    // 循环取出列名并写入表格中  从第二行开始写入列名数据
    for($i=0;$i<$cellNum;$i++){
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'2', $expCellName[$i][1]); 
    } 
    // Miscellaneous glyphs, UTF-8   
    // 循环取出数据列， 
    for($i=0;$i<$dataNum;$i++){
      for($j=0;$j<$cellNum;$j++){
        $objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+3), $expTableData[$i][$expCellName[$j][0]]);
      }             
    }  
    // 设置头信息
    header('pragma:public');
    header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
    header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印
	// 一定要加根 命名空间   \
	$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');  
    $objWriter->save('php://output'); 
    exit;   
}
